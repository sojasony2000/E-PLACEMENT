<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
  
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="css/forme.css">
   </head>
<body>

 <?php
 include "tponav.php";
 ?>
 <br><br><br> <br><br><br> <br><br><br>
<form action="question.php"  method="POST" enctype="multipart/form-data" >
<label for="nameInput">Topic</label>
        <input type="text" id="sub_name" name="sub_name" placeholder="Topic">

        
        <label for="files">File upload</label>
        <input type="file" id="files" name="files"/>

        <button type="submit" value="Add" name="Click">Submit</button>
      </form>
  
      



  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $sub_name=$_POST["sub_name"];
    $filename=$_FILES["files"]["name"];
    $tempname=$_FILES["files"]["tmp_name"];
    $folder="important/".$filename;
    $sql2="insert into tbl_ques(sub_name,large)values('$sub_name','$filename')";
    if(mysqli_query($con,$sql2))
                        { 
                          move_uploaded_file($tempname,$folder);
                          if(headers_sent())
                          {
                            ?>
            <script>
                alert("Inserted successfully");
                </script>
                <?php
                  
                          die('<script type="text/javascript">window.location.href="question.php"</script>');
                          }
                          else{
                          header("location:question.php");
                          die();
            }
        }
      }
    }



?>