<?php
require('stripe-php-master/init.php');
$publishableKey = "pk_test_51LFF2ySCJ8OMN7jSGEPvilxvjiuZSW8V1JDIDKim2lFoDnHSGY1AyDJKBEaFpyUxv4U0v90D7QfNwEgl3JNCt4Rr00JHJs6Qm1";
$secretKey = "sk_test_51LFF2ySCJ8OMN7jSYRabEISPOayTDENBPI4t6faAbyxKXVozVfDFp8hzmeh5xf32J3kj6dJhbgTVlEGNUmkKxDGB003F3SWS0s";
\Stripe\Stripe::setApiKey($secretKey);

?>