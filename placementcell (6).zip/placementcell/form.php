<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/google f.css">
</head>
<body>
<div class="form">
	<div title-div>
	<h1>Google Form</h1>
	<p> This is a google form</p>
	<p>*Required</p>
   </div>
   
   <div class="name-div">
	<div class="name">Name</div>
	<div class="input-div"><input type="input" name="answer" placeholder="Your answer"><div>
   </div>
   
   <div class="name-div">
	<div class="name">EmailId</div>
	<div class="input-div"><input type="input" name="email" placeholder="Your Mailid"><div>
   </div>

   <div class="name-div">
	<div class="name">Enter your college name</div>
	<div class="input-div"><input type="input" name="college" placeholder="Your clge name"><div>
   </div>
   
   <div class="name-div">
	<div class="name">MobileNo</div>
	<div class="input-div"><input type="input" name="answer" placeholder="Your mobile no"><div>
   </div>

   <div class="name-div">
	<div class="name">Course</div>
	<div class="input-div"><input type="input" name="course" placeholder="Your course"><div>
   </div>

   <div class="name-div">
	<div class="name">Have any backlogs</div>
	<div class="input-div"><input type="input" name="answer" placeholder=""><div>
   </div>

   <div>
        <input class="btn" type="submit" name="Submit">
   </div>

   <div>
    <p class="term">This content is either endorsed norcrested by Google, Repot Abuse-Term of Service-Private Policy</p>
   </div>
   <h2>Google Form</h2>
	
</div>
	





</body>
</html>