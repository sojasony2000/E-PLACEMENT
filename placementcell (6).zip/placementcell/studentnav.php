<div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Student</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="student dashboard.php" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="recruit.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">New Drives</span>
          </a>
        </li>
        <li>
          <a href="event1.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Events</span>
          </a>
        </li>
        <li>
          <a href="reg1.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Additional Info</span>
          </a>
        </li>
        <li>
          <a href="profile.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Profile</span>
          </a>
        </li>
        <li>
          <a href="ques1.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Questions</span>
          </a>
        </li>
        <li>
          <a href="mock1.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Other Events</span>
          </a>
        </li>
        <li>
          <a href="alert.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Training Programmes</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout1.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <?php
      $pic="select photo from adn_tbl where log_id=$r[log_id]";
      $check=mysqli_query($con,$pic);
      $fe=mysqli_fetch_array($check);
      ?>
      <div class="profile-details">
        <img class="img-profile rounded-circle" src="studentimage/<?php echo $fe['photo'];?>" style="max-width: 60px">
                <span class="photo"><?= $r['1']?></span>
        <i class='' ></i>
      </div>
    </nav>