<html>
    <link rel="stylesheet" type="text/css" href="CSS/style1.css">
		<nav class="navbar navbar-fixed-top" id="top-nav">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" href="#">Campus Recruitment System</a>
				</div>
				<ul id="list1" class="nav navbar-nav">
					<li class="active"><a href="home.php">Home</a></li>
				</ul>
			</div>
		</nav>
	  </head>
	  <body>
		<div class=" container-fluid " id="dash" >
		<h2>COMPANY REGISTRATION</h2>
		<form action="company.php" method="POST">
        <div class="container">
		   <h3>Company Details</h3>
           <hr>
           <ol>
           <li><label for="name"><b>Name:</b></label>
           <input type="text" placeholder="Enter in capital letters" name="name" required></li>
		   
		   <li><label for="email"><b>Email(Username):</b></label>
           <input type="email" placeholder="abc@xyz.com" name="email" required></li>
		   
		   <li><label for="pwd"><b>Password:</b></label>
           <input type="password" name="pwd" placeholder="minimum 6 characters" required></li>

           <li><label for="phone"><b>Contact number:</b></label>
           <input type="number" placeholder="10 digits" name="phone" required ></li>

          <li><label for="location"><b>Location:</b></label>
          <input type="text" placeholder="Ex. Delhi" name="location" required ></li>
		  
		  <li><label for="worth"><b>Net Worth:</b></label>
           <input type="number" placeholder="in crores" name="worth" required ></li>
		  
		  
		 
		  </ol>
          <hr>

   
    <button type="submit" class="registerbtn">Add</button>
  </div>
</form>
  
</html>

<?php
if(isset($_POST["submit"]))
{
    $name=$_POST["name"];
    $email=$_POST["email"];
    $phone=$_POST["phone"];





?>