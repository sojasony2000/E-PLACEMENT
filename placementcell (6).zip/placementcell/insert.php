<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="css/style5.css" rel="stylesheet">
    <script type="text/javaScript">
     function registration()
      {

        const name = document.getElementById('name');
        const username=document.getElementById('username');
        const password = document.getElementById('password');
        const cpassword = document.getElementById('cpassword');
        const message =document.getElementsByClassName('message');

        var n = document.form.numbers.value;
        var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
          var letters = /^[A-Za-z]+$/;
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          

          if (isNaN(n)) {
            ocument.getElementById(
                      "adno").innerHTML =
                      "Please enter Numeric value";
                    return false;
                } else {
                  document.getElementById(
                      "adno").innerHTML = 
                      "Numeric value is: " + n;
                    return true;
                }
          if(document.getElementById("uname").value=='')
          {
            uname.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Please enter the username.';
              return false;

          }
          else if(!letters.test(document.getElementById("uname").value==''))
          { 
            uname.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'User name field required only alphabet characters';
              return false;

          }
          else if(document.getElementById("uname").value.length < 6)
          {
            uname.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Username  minimum length is 6';
              return false;

          }
          else{
            uname.style.border="3px solid green";
          }
          
          if(document.getElementById("pass").value=='')
          {
            pass.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Please enter Password';
              return false;

          }
          else if(!pwd_expression.test(document.getElementById("pass").value))
          {
            pass.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Upper case, Lower case, Special character and <br>Numeric letter are required in Password filed';
              return false;

          }
         
          else if(document.getElementById("pass").value.length < 6)
          {
            pass.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Password minimum length is 6';
              return false;

          }
          else{
            pass.style.border="3px solid green";
          }

         if(document.getElementById("pass_repeat").value=='')
          {
            pass_repeat.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Enter Confirm Password';
              return false;

          }
         
          else if(document.getElementById("pass_repeat").value.length > 12)
          {
            pass_repeat.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Password max length is 12';
              return false;

          }
          else if(document.getElementById("pass").value != document.getElementById("pass_repeat").value)
          {
            pass_repeat.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Password not Matched';
              return false;

          }
          else
          {		
            pass_repeat.style.border="3px solid green";		                            
            document.getElementById("demo").innerHTML = 'Thank You for registering';
               return true;
          }
      }
      </script>  
   </head>
<body>
  <?php
  include "tponav.php";
  ?>
    <br><br><br>
    <br><br><br>
    <form  action="insert.php" method="POST" name="frm"  enctype="multipart/form-data" onsubmit="return registration();>
  <div class="container">
    <br><h1>Add</h1>
    <hr>

    <label for="Ad.No"><b>Admission No:</b></label>
    <input type="text" placeholder="Enter Admission No:" name="adno" id="adno" required>

    <label for="uname"><b>Name:</b></label>
    <input type="text" placeholder="Enter username" name="uname" id="uname" required>

    <label for="psw"><b>Password:</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="pass" required>

    <label for="psw-repeat"><b>Repeat Password:</b></label>
    <input type="password" placeholder="Repeat Password" name="pass-repeat" id="pass-repeat" required>
    <hr>
    <label for="pic"><b>Upload Image:</b></label>
    <input type="file" placeholder="" name="pic" id="pic" required>
    <hr>
    <tr>
  <td><input type ="hidden" name="usertype" value="student"></td>
    </tr>

    <button type="submit" class="registerbtn" name="Click">Add</button>
  </div>

  <div class="container signin">
  </div>
</form>
    

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $adno=$_POST['adno'];
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];
    $usertype=$_POST["usertype"];
    $filename=$_FILES["pic"]["name"];
    $tempname=$_FILES["pic"]["tmp_name"];
    $folder="studentimage/".$filename;
    $sql="select * from log_tbl where uname='$uname'";
    $res=mysqli_query($con,$sql);
    $count=mysqli_num_rows($res);
    if($count>0)
    {
      ?>
       <script>
       alert("Ooops! Username Already In Use");
       </script>
      <?php
    }
    else{
    $sql1="insert into log_tbl(uname,pass,usertype,status)values('$uname','$pass','$usertype',1)";
    if(mysqli_query($con,$sql1))
    {
      $last_id=mysqli_insert_id($con);
      $sql2="insert into adn_tbl(adno,uname,pass,log_id,photo)values('$adno','$uname','$pass','$last_id','$filename')";
       
                        if(mysqli_query($con,$sql2))
                        { 
                          move_uploaded_file($tempname,$folder);
                          if(headers_sent())
                          {
                            ?>
            <script>
                alert("Inserted successfully");
                </script>
                <?php
                  
                          die('<script type="text/javascript">window.location.href="insert.php"</script>');
                          }
                          else{
                          header("location:insert.php");
                          die();
            }
        }
      }
    }
}
}
?>