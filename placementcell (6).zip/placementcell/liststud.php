<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);



/*if($r[4]==1)
{

  $query1="SELECT * FROM reg_tbl where log_id ='$id'";
  $res1 = mysqli_query($con,$query1);
  $r1=mysqli_fetch_array($res1);*/



    

?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link rel="stylesheet" href="css/userdetails.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
    <script src="js/button.js"></script>
    <script type="text/stylesheet" href="css/dd.css"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Admin</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="dashboard.php" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="liststud.php" class="active">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Student List</span>
          </a>
        </li>
        <li>
          <a href="addtutor.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Tutor</span>
          </a>
        </li>
        <li>
          <a href="tutorlist.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Tutor List</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Placements</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Events</span>
          </a>
        </li>
       
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="profile-details">
        <img src="images/profile.jpg" alt="">
        <span class="admin_name"><?= $r['1']?></span>
        <i class='' ></i>
      </div>
    </nav>


    <br><br><br><br><br><br><br><break><div class="row mb-3">
    
           
          <h2><u>Student List</u></h2><br><br>
           <table width="100%" border="3" style="border-collapse:collapse;">
 <thead>
 <tr>
 <th><center><strong>S.No</strong></center></th>
 <th><center><strong>Id</strong></center></th>
 <th><center><strong>Log_id</strong></center></th>
 <th><center><strong>Name</strong></center></th>
 <th><center><strong>Address</strong></center></th>
 <th><center><strong>Email</strong></center></th>
 <th><center><strong>Phone</strong></center></th>
 <th><center><strong>Status</strong></center></th>
 </tr>
 </thead>
 <tbody>
 <?php
 $count=1;
 
 $sel_query="select log_tbl.*,reg_tbl.* from log_tbl,reg_tbl where log_tbl.log_id=reg_tbl.log_id"; 
 $result = mysqli_query($con,$sel_query);
 while($row = mysqli_fetch_assoc($result)) { ?>
 <tr><td><center><?php echo $count; ?></center></td>
 <td><center><?php echo $row["id"]; ?></center></td>
 <td><center><?php echo $row["log_id"]; ?></center></td>
 <td><center><?php echo $row["name"]; ?></center></td>
 <td><center><?php echo $row["address"]; ?></center></td>
 <td><center><?php echo $row["email"]; ?></center></td>
 <td><center><?php echo $row["phone"]; ?></center></td>
 <td><center><?php echo $row["status"]; ?></center></td>
 <td><center>
 <button class="btn btn-primary" onclick="myFunction()"><a href="studblock.php?id=<?php echo $row["log_id"]; ?>" class="text-light">Block</a></button>
 </td>
 <td><center>
 <button class="btn btn-primary" onclick="myFunction()"><a href="studunblock.php?id=<?php echo $row["log_id"]; ?>"class="text-light">Unblock</a></button>
 </td>
 </tr>
 <script>		
function myFunction() 
{
  
        document.getElementById('btn')
        alert("Blocked!");
        document.getElementById('btn').prop('disabled',true);
        else
        alert("UnBlocked");
}	            
</script>
 <?php $count++; } ?>
 </tbody>
 </table>

    <script>
      
        let sidebar = document.querySelector(".sidebar");
     let sidebarBtn = document.querySelector(".sidebarBtn");
     sidebarBtn.onclick = function() {
       sidebar.classList.toggle("active");
       if(sidebar.classList.contains("active")){
       sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
     }else
       sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
     }
     
      </script>
     
     </body>
     </html>
<?php
}

?>
    