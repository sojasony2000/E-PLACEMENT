
<?php

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception; 
require 'src\Exception.php'; 
require 'src\PHPMailer.php'; 
require 'src\SMTP.php'; 

include('connect.php');
 $sel_query="SELECT * FROM `tbl_reg`,tbl_regn where tbl_reg.log_id=tbl_regn.log_id and tbl_reg.mark_ten>60 and tbl_reg.mark_two>60 and tbl_reg.mark_ug>60 and tbl_reg.mark_pg>60"; 
 $result = mysqli_query($con,$sel_query);
 while($row = mysqli_fetch_assoc($result))
  { 
    $eemail=$row['email'];


//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'eplacement2022@gmail.com';                     //SMTP username
    $mail->Password   = 'pfttdqvjnbrurksj';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('eplacement2022@gmail.com', 'placement 2022');
    $mail->addAddress($eemail);     //Add a recipient
  //  $mail->addAddress('ellen@example.com');               //Name is optional
  //  $mail->addReplyTo('info@example.com', 'Information');
  //  $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

    //Attachments
   /// $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Infosys is hiring..';
    $mail->Body    = 'Infosys is hiring...Students should have percentage greater than 60 for UG and PG.Last date for registration is 2/03/2022.
            Register on the link below:
            http://localhost/placementcell/tcsform.php';
    $mail->AltBody = 'Thanks For your Interest';

    $mail->send();
    echo "<script>alert('Message has been Sent');window.location.href='list.php';</script>";
   
  }

?>