<div class="sidebar">
<div class="logo-details">
  <i class='bx bxl-c-plus-plus'></i>
  <span class="logo_name">TPO</span>
</div>
  <ul class="nav-links">
  <li>
      <a href="insert.php">
        <i class='bx bx-list-ul' ></i>
        <span class="links_name">Add Student</span>
      </a>
    </li>
    
    <li>
      <a href="recruitment.php">
        <i class='bx bx-list-ul' ></i>
        <span class="links_name">Add Drives</span>
      </a>
    </li>

    <li>
      <a href="question.php">
        <i class='bx bx-list-ul' ></i>
        <span class="links_name">Study Materials</span>
      </a>
    </li>


    <li>
      <a href="list.php">
        <i class='bx bx-list-ul' ></i>
        <span class="links_name">Student List</span>
      </a>
    </li>
    <li>
      <a href="events.php">
        <i class='bx bx-coin-stack' ></i>
        <span class="links_name">Events</span>
      </a>
    </li>
    <li>
      <a href="company1.php">
        <i class='bx bx-coin-stack' ></i>
        <span class="links_name">Training Programmes</span>
      </a>
    </li>
    <li>
      <a href="#">
        <i class='bx bx-coin-stack' ></i>
        <span class="links_name">Add Notification</span>
      </a>
    </li>
   
    
    <li class="log_out">
      <a href="logout1.php">
        <i class='bx bx-log-out'></i>
        <span class="links_name">Log out</span>
      </a>
    </li>
  </ul>
</div>
<section class="home-section">
<nav>
  <div class="sidebar-button">
    <i class='bx bx-menu sidebarBtn'></i>
    <span class="dashboard">Dashboard</span>
  </div>
  <div class="profile-details">
    <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
            <span class="photo"><?= $r['1']?></span>
    <i class='' ></i>
  </div>
</nav>