<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);




?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Student Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
    </table>  <link href="css/userprofile3.css" rel="stylesheet">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
 <?php
 include "studentnav.php";
 ?>


    <div class="row mb-3">
          <?php 

$id=$_SESSION["log_id"];
$sql ="SELECT * FROM tbl_regn where log_id='$id'";  
$result=mysqli_query($con,$sql);
  if($result)
  {
      while($row=mysqli_fetch_assoc($result))
      {


?>

<form action="profile.php" method="POST" name="frm" id="form" class="frm" >

<div class="error"><p id="demo"></p></div>
<table width="100%" border="3" style="border-collapse:collapse;">
<tr>
<th><center><strong>Enrollment No:</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter the no" name="no" id="name"autocomplete="off" readonly value="<?php echo $row['no'];?>"></center></td>
</tr>
<tr>
<th><center><strong>Name</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter  Name" name="s_name" id="lname"autocomplete="off" readonly value="<?php echo $row['s_name'];?>"></center></td>
</tr>
<tr>
<th><center><strong>Father Name</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter father Name" name="father_name" id="lname"autocomplete="off" readonly value="<?php echo $row['father_name'];?>"></center></td>
</tr>
<th><center><strong>Address</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" id="address" name="address" autocomplete="off" readonly value="<?php echo $row['address'];?>"></center></td>
</tr> 
<tr>
<tr>
<th><center><strong>DOB</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter DOB" name="birth_date" id="birth_date"autocomplete="off" readonly value="<?php echo $row['birth_date'];?>"></center></td>
</tr>
<tr>
<th><center><strong>Email</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" placeholder="Enter The Email Id" id="email" name="email" autocomplete="off" readonly value="<?php echo $row['email'];?>"></center></td>
</tr>
<tr>  
<?php
      }
    }
    ?>


</table>

<button type="submit" name="Click" class="button1"><a href="update.php" >Update</a></button>

</form>
   

  <script>
      
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php 
}

            else
            {
                if(headers_sent())
                    {
                         die('<script type="text/javascript">window.location.href="profile.php?e=1"</script>');
                     }
            else
            {
            header("location:profile.php?e=1");
            die();
            }
        }
            

?>