<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Student Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/event.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css2/font-awesome.min.css" rel="stylesheet">
    <link href="css2/bootstrap.min.css" rel="stylesheet">
  
   </head>
<body>
  <?php
  include "studentnav.php";
  ?>
  <br><br><br><br> <br><br><br><br>

<?php
                     $count=1;
                    $sel_query="select * from event_tbl as event_id ";
                    $result = mysqli_query($con,$sel_query);
                    while($row = mysqli_fetch_assoc($result))
                    { ?>
  <class="blog-page-section">
<div class="auto-container">
<div class="row clearfix">

<div class="news-block col-lg-4 col-md-6 col-sm-12">
<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
<div class="image">
<a href="#"><img src="uploads/default.jpg" alt="" width="100%" height="200" /></a>
</div>
<div class="lower-content">
<h2><?php echo $row["event_name"];?><br></h2>
<div class="clearfix">
<div class="pull-left">
<div class="author" style="padding-left: 0px;">
Added on: <?php echo $row["event_date"];?><br><?php echo $row["event_time"];?> </div>
</div>
<div class="pull-right">
<ul class="post-info">
<?php echo $row["event_desc"];?>
</ul>
</div>
</div>
</div>
</div>
</div>
  <script>
      
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php 
}
}

?>