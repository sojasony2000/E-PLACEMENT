<?php
session_start();
include "connect.php";
if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

?>
<html>
    <link rel="stylesheet" href="css/reg2.css">
<head>
    <title>Registration Form</title>
</head>
<body>
    <div class="container">
        <header>Registration</header>

        <form action="reg1.php" method="POST">
            <div class="form first">
                <div class="details">
                    <span class="title">Information</span>

                    <div class="fields">
                    <div class="input-field">
                            <label>Enrollment No:</label>
                            <input type="number" name="no" id="no" placeholder="Enter your enrollment no"  required>
                        </div>

                        <div class="input-field">
                            <label>Full name:</label>
                            <input type="text" name="s_name" id="s_name" placeholder="Enter your name" maxlength="18" onkeypress='style=' text-transform: uppercase;''required>
                        </div>

                        <div class="input-field">
                            <label>Father name:</label>
                            <input type="text" name="father_name"id="father_name" placeholder="Enter your father name" maxlength="18" onkeypress='style=' text-transform: uppercase;'' required>
                        </div>
                        
                        <div class="input-field">
                            <label>Address:</label>
                            <input type="text" name="address"id="address" placeholder="Enter your address"  maxlength="60" onkeypress='' required>
                        </div>

                        <div class="input-field">
                            <label>Date Of Birth:</label>
                            <input type="date" name="birth_date" id="birth_date" placeholder="Enter birth date"  maxlength="32"" onkeypress='' required>
                        </div>

                        <div class="input-field">
                            <label>Email:</label>
                            <input type="email"name="email"id="email" placeholder="Enter email" required>
                        </div>

                       
                    </div>
                </div>

                
                        
                    <br>
                    <button class="submit">
                    <input type="submit" value="Add" name="Click">
                    <br><br><br><br><br></span>
                        </button>
                       

                        <button class="submit" ><a href="student dashboard.php">Back</a></button>
                    </div>
                </div>   
            </div>     
        <form>       
    </body>

</html>

<?php
if(isset($_POST["Click"])){
    $no=$_POST["no"];
    $s_name=$_POST["s_name"];
    $father_name=$_POST["father_name"];
    $address=$_POST["address"];
    $birth_date=$_POST["birth_date"];
    $email=$_POST["email"];
    $id=$_SESSION['log_id'];
    $sql="insert into tbl_regn(no,s_name,father_name,address,birth_date,email,status,log_id)values('$no','$s_name','$father_name','$address','$birth_date','$email',1,'$id')";
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="reg1.php?e=1"</script>');
                     }
            else
            {
            header("location:student dashboard.php?e=1");
            die();
            }
        }
    }
    }    
?>

</script>
<?php


mysqli_close($con);			
?> 