<?php
session_start();
include "connect.php";
?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Register</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900' rel='stylesheet' type='text/css'>
<link href="//cdn.jsdelivr.net/npm/featherlight@1.7.14/release/featherlight.min.css" type="text/css" rel="stylesheet" />
<script src='https://www.google.com/recaptcha/api.js' async defer></script>

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
<style>
    button:disabled{
        cursor:no-drop;
    }
	/*#form-box{
		display:none;	
	}*/
	#actual_form{
		display:none;	
	}
	#ugpg_choice_passout{
		display:none;
	}
	#ugpg_choice_finalyear{
		display:none;
	}
	#job_choice_passout{
		display:none;
	}
	/*#job_choice_finalyear{
		display:none;
	}*/
	#job_choice{
		display:none;
	}
	#reset{
	    display:none;
	}
	
	#captchacheck{
        display:none;
    }
    .featherlight .featherlight-inner 
    {
                display: block !important;
    }
    #captcha_check_link{
        display:none;
    }
    .g-recaptcha {
        display: inline-block;
    }
</style>
</head>
<!--<body>
<a href="#" data-featherlight="#captchacheck" id="captcha_check_link">Open element in lightbox</a>
<div id="captchacheck" hidden>Please check the captcha.</div>
<div class="page-wrapper">

<div class="preloader"></div>

<header class="main-header">

<div class="header-upper">
<div class="auto-container">
<div class="clearfix">
<div class="pull-left logo-box">
<div class="logo"><a href="home.php"><img src="images/gupsc-logo.png" alt="" title="Gour University Placement and Startup Cell"></a></div>
</div>
<div class="nav-outer clearfix">

<nav class="main-menu navbar-expand-md">
<div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
<ul class="navigation clearfix">
<li><a href="home.php"> <i class="fa fa-home"></i></a></li>
<li class="dropdown"><a href="#">About Us</a>
<ul>
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>

</ul>
</li>
<li class="dropdown"><a href="#">Placement</a>
<ul>

<li><a href="content.php?type=1&what=2">Upcoming Events</a></li>
<li><a href="content.php?type=1&what=3">Activities</a></li>
<!--<li><a href="placement-record.php">Placement Record</a></li>
<li><a href="page.php?id=99">Placement Reports</a></li>-->
<!--<li><a href="reg.php">Register</a></li>
<li><a href="log1.php">Login</a></li>
<!--<li><a href="create-login-info.php">Generate Login</a></li>
<li><a href="online-payment.php">Online Payment</a></li>-->
</ul>
</li>

<!--<li><a href="online-payment.php">Payment</a></li>-->
<!--<li class="dropdown"><a href="#">Skill Development</a>
<ul>
<!--<li><a href="page.php?id=36">Important Notice</a></li>
<li><a href="page.php?id=88">Skill Development Courses</a></li>-->
<!--<li><a href="page.php?id=93">Activities</a></li>
<li><a href="page.php?id=95">Placement Details</a></li>
</ul>
</li>
<li class="dropdown"><a href="#">Gallery</a>
<ul>
<li><a href="gallery-list.php">Photo Gallery</a></li>
<li><a href="video-gallery.php">Video Gallery</a></li>
</ul>
</li>
<li><a href="contact.php">Contact</a></li>
</ul> </div>
</nav>
</div>
</div>
</div>
</div>


<div class="sticky-header">
<div class="auto-container clearfix">

<div class="logo pull-left">
<a href="home.php" class="img-responsive"><img src="images/gupsc-logo.png" alt="" title=""></a>
</div>

<div class="right-col pull-right">

<nav class="main-menu navbar-expand-md">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent1">
<ul class="navigation clearfix">
<li><a href="home.php"> <i class="fa fa-home"></i></a></li>
<li class="dropdown"><a href="#">About Us</a>
<ul>
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
<!--<li><a href="chancellor-message.php">Chancellor Message</a></li>
<li><a href="vice-chancellor-message.php">Vice-Chancellor Message</a></li>-->
</ul>
</li>
<!--<li class="dropdown"><a href="#">Placement</a>
<ul>

<li><a href="content.php?type=1&what=2">Upcoming Events</a></li>
<li><a href="content.php?type=1&what=3">Activities</a></li>
<!--<li><a href="placement-record.php">Placement Record</a></li>
<li><a href="page.php?id=99">Placement Reports</a></li>-->
<!--<li><a href="reg.php">Register</a></li>
<li><a href="login.php">Login</a></li>
<!--<li><a href="create-login-info.php">Generate Login</a></li>
<li><a href="online-payment.php">Online Payment</a></li>-->
</ul>
</li>
<!--<li class="dropdown"><a href="#">Startup</a>
<ul>
<li><a href="startup-cell-activities.php">Activities</a></li>
<li><a href="start-up.php">Register</a></li>
</ul>
</li>
<li><a href="online-payment.php">Payment</a></li>-->
<!--<li class="dropdown"><a href="#">Skill Development</a>
<ul>
<li><a href="page.php?id=36">Important Notice</a></li>
<li><a href="page.php?id=88">Skill Development Courses</a></li>-->
<!--<li><a href="page.php?id=93">Activities</a></li>
<li><a href="page.php?id=95">Placement Details</a></li>-->
<!--</ul>
</li>-->
<!--<li class="dropdown"><a href="#">Gallery</a>
<ul>
<li><a href="gallery-list.php">Photo Gallery</a></li>
<li><a href="video-gallery.php">Video Gallery</a></li>
</ul>
</li>
<li><a href="contact.php">Contact</a></li>
</ul> </div>
</nav>
</div>
</div>
</div>



</header> 

<section class="page-title" style="background-image:url(images/background/pattern-21.png)">
<div class="auto-container">

<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-6.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-7.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-8.png)"></div>

<div class="icon-four" style="background-image:url(images/icons/icon-9.png)"></div>

<div class="icon-five" style="background-image:url(images/icons/icon-10.png)"></div>

<div class="icon-six" style="background-image:url(images/icons/icon-6.png)"></div>
</div>
<div class="inner-container clearfix">
<div class="pull-left">
<h1>Register</h1>
</div>
<div class="pull-right">
<ul class="bread-crumb clearfix">
<li><a href="index.php">Home</a></li>
<li>Register</li>
</ul>
</div>
</div>
</div>
</section>


<section class="contact-page-section">
<div class="auto-container contact-form">
<div class="row clearfix">

</div>



</div>-->

<!--<div class="contact-form">
<form method="post" action="" id="contact-form" enctype="multipart/form-data">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 text-center">
<button class="theme-btn btn-style-four" type="button" id="passout_btn">Pass Out Student<span class="icon fa fa-arrow-right"></span></button>
</div>
<div class="col-lg-6 col-md-6 col-sm-12 text-center">
<button href="#" class="theme-btn btn-style-four" type="button" id="finalyear_btn">Final Year Student<span class="icon fa fa-arrow-right"></span></button>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 text-center" id="ugpg_choice_passout">

<label style="display:block;">Passout Students</label>
<select id="passout_ugpg" class="form-control" name="passout_ugpg">
<option value="">Select Course</option>
<option value="passout_ug">UG</option>
<option value="passout_pg">PG</option>
</select>
<br />
</div>
<div class="col-lg-12 col-md-12 col-sm-12 text-center" id="ugpg_choice_finalyear">
<label style="display:block;">Final Year Students</label>

<select id="finalyear_ugpg" name="finalyear_ugpg" class="form-control">
<option value="">Select</option>
<option value="finalyear_ug">UG</option>
<option value="finalyear_pg">PG</option>
</select>
<br />
</div>
<input type="hidden" name="course_type" id="course_type" />
<input type="hidden" name="student_type" id="student_type" value="" />
<div class="col-lg-12 col-md-12 col-sm-12 text-center" id="job_choice">


<select class="form-control" name="job_type" id="job_type">
<option value="">Select Job</option>
<option value="industry_job">Industry Job</option>
<option value="govt_job">Govt Job</option>
</select>
<input type="hidden" name="job_type_hidden" value="" id="job_type_hidden" />
</div>-->
</div>

<br /><br />
<div id="form-box">
<div class="sec-title centered">
<div class="title">Register here... </div>
<form action="reg.php" method="POST" name="frm"  onsubmit="" >
<div class="separator"><span></span></div>

<br /><br />
<body>
<div class="row clearfix">
<div class="col-lg-3 col-md-3 col-sm-12">
<h5>Kingston University Enrollment Number:</h5>
</div>
<div class='col-lg-9 col-md-9 col-sm-12 form-group'><input type='text' name='enrollment' id='enrollment' placeholder='Enrollment Number' maxlength="11" onkeypress='style=' text-transform: uppercase;'' required></div> </div>
<h3><b>Personal Details:</b></h3>
<div class="row clearfix">
<div class="col-lg-3 col-md-3 col-sm-12">
<h5>Name of the applicant:</h5>
</div>
<div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='first_name' id='first_name' placeholder='First Name' maxlength="18" onkeypress='style=' text-transform: uppercase;'' required></div>

<div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='middle_name' id='middle_name' maxlength="18" placeholder='Middle Name'></div><div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='last_name' id='last_name' placeholder='Last Name' maxlength="18" onkeypress='style=' text-transform: uppercase;'' required></div> <div class="col-lg-3 col-md-3 col-sm-12">
<h5>Father's Name:</h5>
</div>
<div class='col-lg-9 col-md-9 col-sm-12 form-group'><input type='text' name='father_name' id='father_name' placeholder='Father' s Name' maxlength="50" onkeypress='style=' text-transform: uppercase;'' required></div>
<div class="col-lg-3 col-md-3 col-sm-12">
<h5>Address:</h5>
</div>
<div class='col-lg-9 col-md-9 col-sm-12 form-group'><input type='text' name='address1' id='address1' placeholder='Address' maxlength="60" onkeypress='' required></div>
<div class="col-lg-3 col-md-3 col-sm-12">&nbsp</div>
<div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='city' id='city' placeholder='City' maxlength="16" onkeypress='' required></div><div class='col-lg-3 col-md-3 col-sm-12 form-group'><select name='state' id='' class='form-control' required><option value=''>Select State</option><option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option><option value="Andhra Pradesh">Andhra Pradesh</option><option value="Arunachal Pradesh">Arunachal Pradesh</option><option value="Assam">Assam</option><option value="Bihar">Bihar</option><option value="Chandigarh">Chandigarh</option><option value="Chhattisgarh">Chhattisgarh</option><option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option><option value="Daman and Diu">Daman and Diu</option><option value="Delhi">Delhi</option><option value="Goa">Goa</option><option value="Gujarat">Gujarat</option><option value="Haryana">Haryana</option><option value="Himachal Pradesh">Himachal Pradesh</option><option value="Jammu and Kashmir">Jammu and Kashmir</option><option value="Jharkhand">Jharkhand</option><option value="Karnataka">Karnataka</option><option value="Kerala">Kerala</option><option value="Lakshadeep">Lakshadeep</option><option value="Madhya Pradesh">Madhya Pradesh</option><option value="Maharashtra">Maharashtra</option><option value="Manipur">Manipur</option><option value="Meghalaya">Meghalaya</option><option value="Mizoram">Mizoram</option><option value="Nagaland">Nagaland</option><option value="Orissa">Orissa</option><option value="Pondicherry (Puducherry)">Pondicherry (Puducherry)</option><option value="Punjab">Punjab</option><option value="Rajasthan">Rajasthan</option><option value="Sikkim">Sikkim</option><option value="Tamil Nadu">Tamil Nadu</option><option value="Telangana">Telangana</option><option value="Tripura">Tripura</option><option value="Uttar Pradesh">Uttar Pradesh</option><option value="Uttarakhand">Uttarakhand</option><option value="West Bengal">West Bengal</option><select></div><div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='pincode' id='pincode' placeholder='Pincode' maxlength="" onkeypress='javascript:return acceptOnlyNumbers(event)' required></div>
<div class="col-lg-3 col-md-3 col-sm-12">
<h5>Date of Birth:</h5>
</div>
<div class='col-lg-3 col-md-3 col-sm-12 form-group'><input type='text' name='date_of_birth' id='date_of_birth' placeholder='dd-mm-yyyy' maxlength="32" onkeypress='' required></div> <div class="col-lg-6 col-md-6 col-sm-12">
&nbsp;
</div>
<div class="col-lg-3 col-md-3 col-sm-12">
<h5>Contact Information:</h5>
</div>
<div class='col-lg-4 col-md-4 col-sm-12 form-group'><input type='tel' name='mobile' id='mobile' placeholder='Mobile No.' maxlength="10" onkeypress='javascript:return acceptOnlyNumbers(event)' required></div><div class='col-lg-5 col-md-5 col-sm-12 form-group'><input type='email' name='email' id='email' maxlength="32" placeholder='Email'></div>
</div>
<div class="row clearfix">
<h3><b>Educational Details:</b></h3>
<div class="col-lg-12 col-md-12 col-sm-12 text-center form-group">
<label>10<sup>th</sup></label>
<div class="row">
<input type="hidden" name="tenth[course]" class="text" placeholder="Course" value="" />
<input type="hidden" name="tenth[stream]" class="text" placeholder="Stream" value="" />
<input type="hidden" name="tenth[specialization]" class="text" placeholder="Specialization" value="" />
<div class='col-lg-4 col-md-4 col-sm-4 form-group'><select name='tenth_yr' id='tenth_year' class='form-control'><option value=''>Select Year</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><select></div> <div class="col-lg-4 col-md-4 col-sm-4">
<select name="tenth_board" class="form-control" required>
<option value="">Select</option>
<option value="State Board">State Board</option>
<option value="CBSE">CBSE</option>
<option value="ICSE">ICSE</option>
<option value="Other">Other</option>
</select>
</div>
<div class="col-lg-4 col-md-4 col-sm-4">
<input type="text" name="tenth_percentage" class="text" placeholder="Percentage" onkeypress="javascript:return acceptOnlyNumbers(event)" required />
</div>
</div>
<br /><hr /><br />
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12">12<sup>th</sup></div>
<input type="hidden" name="twelth_course" class="text" placeholder="Course" value="" />
<input type="hidden" name="twelth_stream" class="text" placeholder="Stream" value="" />
<div class='col-lg-4 col-md-4 col-sm-4 form-group'><select name='twelth_year' id='twelth_year' class='form-control'><option value=''>Select Year</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><select></div> <div class="col-lg-4 col-md-4 col-sm-4">
<select name="twelth_board" class="form-control" required>
<option value="">Select</option>
<option value="State Board">State Board</option>
<option value="CBSE">CBSE</option>
<option value="ICSE">ICSE</option>
<option value="Other">Other</option>
</select>
</div>
<div class="col-lg-4 col-md-4 col-sm-4"><input type="text" name="twelth_percentage" class="text" placeholder="Percentage" onkeypress="javascript:return acceptOnlyNumbers(event)" required /></div>

<div class='col-lg-4 col-md-4 col-sm-12 form-group'><select name='twelth_specialization' id='twelth_standard' class='form-control' required><option value=''>Select Specialization</option><option value="PCM">PCM</option><option value="BIOLOGY">BIOLOGY</option><option value="COMMERCE">COMMERCE</option><option value="ART">ART</option><option value="AGRICULTURE">AGRICULTURE</option><option value="OTHER">OTHER</option><select></div> <div class="col-lg-4 col-md-4 col-sm-4">
<!--<input type="text" name="twelth_other_specialization" id="other_specialization" class="text" placeholder="Other Specialization" style="display:none;" />-->
</div>
</div>
 <br /><hr /><br />
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12">Under Graduation</div>

<div class='col-lg-4 col-md-4 col-sm-12 form-group'><select name='ug_course_' id='' class='form-control'><option value=''>Select Course</option><option value="BBA">BBA</option><option value="BCA">BCA</option><option value="BA">BA</option><option value="BSC">BSC</option><option value="BCOM">BCOM</option><option value="LLB 3 YEAR">LLB 3 YEAR</option><option value="LLB 5 YEARS">LLB 5 YEARS</option><option value="B PHARMA">B PHARMA</option><option value="BSC BED">BSC BED</option><option value="BA BED">BA BED</option><select></div> 
<input type="hidden" name="ug[stream]" value="" />
<div class='col-lg-4 col-md-4 col-sm-4 form-group'><select name='ug_year' id='' class='form-control'><option value=''>Select Year</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><select></div>
<div class="col-lg-4 col-md-4 col-sm-4">

<select name="ug_board">
<option value="">Select University</option>
<option value="MG University">MG University</option>
<option value="Calicut University">Calicut University</option>
<option value="APJ Abdul Kalam University">APJ Abdul Kalam University</option>
<option value="Other">Other</option>
</select>
</div>

<input type="hidden" name="ug_specialization" />
</div>
<br />
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4">
<select name="ug_status" id="ug_status">
<option value="">Select Graduation Status</option>
<option value="completed">Completed</option>
<option value="pursuing">Pursuing</option>
</select>
<input type="hidden" name="ug[status]" id="ug_status_hidden" value="" disabled />
</div>
<div class="col-lg-4 col-md-4 col-sm-4" id="ug_percentage">
<input type="text" name="ug_percentage" class="text" placeholder="Percentage" onkeypress="javascript:return acceptOnlyNumbers(event)" />
</div>
<!--<div class='col-lg-4 col-md-4 col-sm-12 form-group' id='ug_semester'><select name='ug[semester_name]' class='form-control'><option value=''>Select Semester</option><option value="SEMESTER 1">SEMESTER 1</option><option value="SEMESTER 2">SEMESTER 2</option><option value="SEMESTER 3">SEMESTER 3</option><option value="SEMESTER 4">SEMESTER 4</option><option value="SEMESTER 5">SEMESTER 5</option><option value="SEMESTER 6">SEMESTER 6</option><option value="SEMESTER 7">SEMESTER 7</option><option value="SEMESTER 8">SEMESTER 8</option><select></div>-->
</div>
<br /><hr /><br />
<div id="pg_row">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12">Post Graduation</div>

<div class='col-lg-4 col-md-4 col-sm-12 form-group'><select name='pg_course' id='' class='form-control'><option value=''>Select Course</option><option value="MA">MA</option><option value="MSC">MSC</option><option value="MCOM">MCOM</option><option value="MBA">MBA</option><option value="MTECH">MTECH</option><option value="MCA">MCA</option><option value="M PHARMA">M PHARMA</option><option value="M. ED.">M. ED.</option><select></div> 
<input type="hidden" name="pg[stream]" value="" />
<div class='col-lg-4 col-md-4 col-sm-4 form-group'><select name='pg_year' id='' class='form-control'><option value=''>Select Year</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><select></div> <div class="col-lg-4 col-md-4 col-sm-4">

<select name="pg_board">
<option value="">Select University</option>
<option value="MG University">MG University</option>
<option value="Calicut University">Calicut University</option>
<option value="APJ Abdul Kalam University">APJ Abdul Kalam University</option>
<option value="Other">Other</option>
</select>
</div>
<div class="col-lg-4 col-md-4 col-sm-4"><input type="text" name="pg_specialization" class="text" placeholder="Specialization" /></div>
</div>
<br />
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4">
<select name="pg_status" id="pg_status">
<option value="">Select Post Graduation Status</option>
<option value="completed">Completed</option>
<option value="pursuing">Pursuing</option>
</select>
<input type="hidden" name="pg[status]" id="pg_status_hidden" value="" disabled />
</div>
<div class="col-lg-4 col-md-4 col-sm-4" id="pg_percentage">
<input type="text" name="pg_percentage" class="text" placeholder="Percentage" onkeypress="javascript:return acceptOnlyNumbers(event)" />
</div>
<!--<div class='col-lg-4 col-md-4 col-sm-12 form-group' id='pg_semester'><select name='pg[semester_name]' class='form-control'><option value=''>Select Semester</option><option value="SEMESTER 1">SEMESTER 1</option><option value="SEMESTER 2">SEMESTER 2</option><option value="SEMESTER 3">SEMESTER 3</option><option value="SEMESTER 4">SEMESTER 4</option><option value="SEMESTER 5">SEMESTER 5</option><option value="SEMESTER 6">SEMESTER 6</option><option value="SEMESTER 7">SEMESTER 7</option><option value="SEMESTER 8">SEMESTER 8</option><select></div> </div>-->
</div>
<br /><hr /><br />


<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12">Other Qualifications</div>

<div class="col-lg-6 col-md-6 col-sm-6">
<select name="field" class="form-control">
<option value="">Select</option>
<option value="Skill Training Program">Skill Development Program</option>
<option value="Project Training">Project Training</option>
<option value="Other">Other</option>
</select>
</div>
<div class="col-lg-6 col-md-6 col-sm-6"><input type="text" name="field_2" class="text" placeholder="Institute Name" /></div>
<div class='col-lg-4 col-md-4 col-sm-4 form-group'><select name='field_year' id='' class='form-control'><option value=''>Select Year</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><select></div> <div class="col-lg-4 col-md-4 col-sm-4">
<input type="text" name="field_percentage" class="text" placeholder="Percentage" onkeypress="javascript:return acceptOnlyNumbers(event)" />
</div>
<!--<div class="col-lg-4 col-md-4 col-sm-4"><input type="text" name="additional[other][other_details]" class="text" placeholder="Other Details" /></div>-->
</div>
</div>
</div>
<div class="row clearfix">
<h3><b>Upload Resume:</b><span style="color:red;">(Max Filesize is 2 MB / Allowed File type is pdf only)</span></h3>
<div class="col-lg-12 col-md-12 col-sm-12 text-center form-group">
<input type="file" name="resume" id="id" class="form-control" />
</div>
</div>

<div class="row clearfix">
<div class="col-lg-12 col-md-12 col-sm-12 text-center form-group" align ="center">

<center><button class="btn btn-primary btn-block" type="submit" id="submitbtn" name="submit" value="Add">Submit</button></center>

</div>
</div>
</div>
</form>
</div>
</div>
</div>
</section>
<button><a href="student dashboard.php" class="next">Back</a></button>


</body>


<!--<footer class="main-footer margin-top" style="background-image:url(images/background/4.jpg);margin-top:60px;">
<div class="auto-container">

<div class="widgets-section">
<div class="row clearfix">

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">

<div class="footer-column col-lg-7 col-md-6 col-sm-12">
<div class="footer-widget logo-widget">
<div class="logo">
<a href="index.php"><img src="images/gupsc-logo.png" alt="" /></a>
</div>
<div class="text">
<p>Placement Cell of the University aims to develop the students in such a way that their academic knowledge and other skills help to build their career in a pre-decided manner.
</p>
</div>

</div>
</div>

<div class="footer-column col-lg-5 col-md-6 col-sm-12">
<div class="footer-widget links-widget">
<h4>About Us</h4>
<ul class="list-link">
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
<li><a href="chancellor-message.php">Chancellor Message</a></li>
<li><a href="vice-chancellor-message.php">Vice-Chancellor Message</a></li>
</ul>
</div>
</div>
</div>
</div>

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">

<div class="footer-column col-lg-6 col-md-6 col-sm-12">
<div class="footer-widget links-widget">
<h4>Important Links</h4>
<ul class="list-link">
<li><a href="placement-upcoming-events.php">Upcoming Events</a></li>
<li><a href="placement-cell-activities.php">Activities</a></li>
<li><a href="page.php?id=8">Placement Record</a></li>
<li><a href="startup-cell-activities.php">Activities</a></li>
<li><a href="online-quiz.php">Online Quiz</a></li>
<li><a href="https://gupsc.net/webmail/">Manage Mail</a></li>
</ul>
</div>
</div>

<div class="footer-column col-lg-6 col-md-6 col-sm-12">
<div class="footer-widget gallery-widget">
<h4>Gallery</h4>
<ul class="list-link">
<li><a href="gallery.php?id=3">Innovation Marathon</a></li>
<li><a href="gallery.php?id=4">Design Thinking and Business Idea Competition</a></li>
<li><a href="gallery.php?id=5">Two Days workshop of personality development</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="footer-bottom">
<div class="auto-container">
<div class="inner-container">
<div class="row clearfix">

<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
<div class="copyright">2020-2022 &copy; Powered by <a href="https://cyberdairy.com">Kingston college</a></div>
</div>

<div class="social-column col-lg-6 col-md-6 col-sm-12">

<a href="disclaimer.php" style="color:#ffffff;"><strong>Disclaimer</strong></a>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>-->


<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-up"></span></div>
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/validate.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCykRLEzpOdEoBqafqgeaJwgjxd3cT1bM8"></script>
<script src="js/map-script.js"></script>


<script>
    function acceptOnlyNumbers(event) {
        var iKeyCode = (event.which) ? event.which : event.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }
  </script>
<script>
      function validateFile(){
          submit = document.getElementById("submitbtn");
          id = document.getElementById("submitbtn");
      }
  </script>

<script>
        $('#file').on('change', function() { 
            const size =  
               (this.files[0].size / 1024 / 1024).toFixed(2); 
  
            if (size > 1) { 
                alert("File must be upto the size of 1 MB"); 
            } else { 
                $("#output").html('<b>' + 
                   'This file size is: ' + size + " MB" + '</b>'); 
            } 
        }); 
  </script>
</body>
</html>

<?php
if(isset($_POST["submit"]))
{
    $enrollment=$_POST["enrollment"];
    $first_name=$_POST["first_name"];
    $middle_name=$_POST["middle_name"];
    $last_name=$_POST["last_name"];
    $father_name=$_POST["father_name"];
    $address1=$_POST["address1"];
    $city=$_POST["city"];
    $state=$_POST["state"];;
    $mobile=$_POST["mobile"];
    $email=$_POST["email"];
    $tenth_yr=$_POST["tenth_yr"];
    $pincode=$_POST["pincode"];
    $date_of_birth=$_POST["date_of_birth"];
    $tenth_yr=$_POST["tenth_yr"];
    $tenth_board=$_POST["tenth_board"];
    $tenth_percentage=$_POST["tenth_percentage"];
    $twelth_year=$_POST["twelth_year"];
    $twelth_board=$_POST["twelth_board"];
    $twelth_percentage=$_POST["twelth_percentage"];
    $twelth_specialization=$_POST["twelth_specialization"];
    $ug_course=$_POST["ug_course"];
    $ug_year=$_POST["ug_year"];
    $ug_board=$_POST["ug_board"];
    $ug_status=$_POST["ug_status"];
    $ug_percentage=$_POST["ug_percentage"];
    $pg_course=$_POST["pg_course"];
    $pg_year=$_POST["pg_year"];
    $pg_board=$_POST["pg_board"];
    $pg_specialization=$_POST["pg_specialization"];
    $pg_status=$_POST["pg_status"];
    $pg_percentage=$_POST["pg_percentage"];
    $field=$_POST["field"];
    $field_2=$_POST["field_2"];
    $field_year=$_POST["field_year"];
    $field_percentage=$_POST["field_percentage"];
    $resume=$_POST["resume"];

    
    $sql="insert into reg1_tbl(enrollment,first_name,middle_name,last_name,father_name,address1,status,city,state,pincode,date_of_birth,mobile,email,tenth_yr,tenth_board,tenth_percentage,twelth_year,twelth_board,twelth_percentage,twelth_specialization,ug_course,ug_year,ug_board,ug_status,ug_percentage,pg_course,pg_year,pg_board,pg_specialization,pg_status,pg_percentage,field,field_2,field_year,field_percentage,resume)values('$enrollment','$first_name','$middle_name','$last_name','$father_name','$address1','$status','$city','$state','$pincode','$date_of_birth','$mobile','$email','$tenth_yr','$tenth_board','$tenth_percentage','$twelth_year','$twelth_board','$twelth_percentage','twelth_specialization','$ug_course','$ug_year','$ug_board','$ug_status','$ug_percentage','$pg_course','$pg_year','$pg_board','$pg_specialization','$pg_status','$pg_percentage','$field','$field_2','$field_year','$field_percentage','$resume')";
    
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="reg.php?e=1"</script>');
                     }
            else
            {
            header("location:reg.php?e=1");
            die();
            }
        }
  
    }    
?>

<?php


mysqli_close($con);			
?> 
    