<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Tutor Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
    <link href="css/ruang-admin.min.css" rel="stylesheet">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Tutor</span>
    </div>
      <ul class="nav-links">
        
        <li>
          <a href="drive.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Drives</span>
          </a>
        </li>
        <li>
          <a href="company.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Companies</span>
          </a>
        </li>
        
       
        <li class="log_out">
          <a href="logout1.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="profile-details">
        <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
                <span class="photo"><?= $r['1']?></span>
        <i class='' ></i>
      </div>
    </nav>

    <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Basic Details</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Basic Details</li>
            </ol>
          </div>

          <div class="row mb-3">
          <form action="drive.php" method="POST" name="frm" enctype="multipart/form-data" id="form" >
<div class="error"><p id="demo"></p></div>
<table >
<tr>
<td><label>Company Name:</label></td>
<td class="tdi"><input type="date" placeholder="Enter The company Name" name="company" id="company"autocomplete="off">
<div class="error" id="demo1"></div></td>
</tr>
<tr>
<td><label>Description</label></td>
<td class="tdi"><input type="text"placeholder="" id="desc" name="desc" autocomplete="off">
<div class="error" id="demo3"></div></td>
</tr>
<tr>
<td><label>Link</label></td>
<td class="tdi"><input type="text"placeholder=""id ="link" name="link" autocomplete="off">
<div class="error" id="demo4"></div></td>
</tr>
<tr>
<td><label>Upload Image</label></td>
<td class="tdi"><input type="file"  placeholder="" id="pic" name="pic">
<div class="error" id="demo8"></div></td>
</tr><br>

    
</table>

<input type="submit" name="Click" class="sub" value="Insert"/>
</form>
    

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php 
}
            else
            {
                if(headers_sent())
                    {
                         die('<script type="text/javascript">window.location.href="drive.php?e=1"</script>');
                     }
            else
            {
            header("location:drive.php?e=1");
            die();
            }
        }
            

?>