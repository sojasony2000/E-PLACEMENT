<?php
session_start();
include "connect.php";
if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

?>
<html>
    <link rel="stylesheet" href="css/reg3.css">
    
<head>
    <title>Question Add</title>
</head>
<body>
    <div class="container">
        <header>Add Questions</header>

        <form action="exam1.php" method="POST">
            <div class="form first">
                <div class="details">
                    <!--<span class="title">Information</span>-->

                    <div class="fields">
                    <div class="input-field">
                            <label>Qn No:</label>
                            <input type="number" name="q_no" id="q_no" placeholder="Enter  no" required>
                        </div>
                    </div>

                    <div class="fields">
                        <div class="input-field">
                            <label>Question:</label>
                            <input type="text" name="exam_question" id="exam_question" placeholder="Enter the question" maxlength="100" onkeypress='style=' text-transform: uppercase;''required>
                        </div>
                    </div>

                    <div class="fields">
                    <div class="input-field">
                            <label>Choice A:</label>
                            <input type="text" name="exam_ch1"id="exam_ch1" placeholder="Enter first question" maxlength="100" onkeypress='style=' text-transform: uppercase;'' required>
                        </div>
                    </div>
                    
                    <div class="fields">
                        <div class="input-field">
                            <label>Choice B:</label>
                            <input type="text" name="exam_ch2"id="exam_ch2" placeholder="Enter second question"  maxlength="100" onkeypress='' required>
                        </div>
                    </div>

                    <div class="fields">
                        <div class="input-field">
                            <label>Choice C:</label>
                            <input type="text" name="exam_ch3"id="exam_ch3" placeholder="Enter third question"  maxlength="100" onkeypress='' required>
                        </div>
                     </div

                     <div class="fields">
                        <div class="input-field">
                            <label>Choice D:</label><br>
                            <input type="text" name="exam_ch4"id="exam_ch4" placeholder="Enter fourth question"  maxlength="100" onkeypress='' required>
                        </div>
                    </div>

                    <div class="fields">
                        <div class="input-field">
                            <label>Correct Answer:</label>
                            <input type="text"name="exam_answer"id="exam_answer" placeholder="Enter correct answer" required>
                        </div>
                    </div>
                      
                    <div class="fields">
                        <div class="input-field">
                            <label>Exam time:</label>
                            <input type="text"name="exam_tm"id="exam_tm" placeholder="Enter correct answer" required>
                        </div>
                    </div>
                    
                </div>
                    <br>
                    <button class="submit">
                    <input type="submit" value="Add" name="Click">
                    </span>
                        </button>
                       

                        <button class="submit" ><a href="tpo dashboard.php">Back</a></button>
                    </div>
                </div>   
            </div>     
        <form>       
    </body>
    <script type="text/javascipt">
        function load_total_que()
        {
            var xmlhttp=new XMLHttpRequest();
            xmlhttp.onreadystatechange=function(){
            if(xmlhttp.readyState == 4 && xmlhttp.status = 200)
                {
                    document.getElementById("countdowntimer").innerHtml=xmlhttp.responseText;
                }
                
        
    };
    xmlhttp.open("GET","foarajax/load_total_que.php?tbl_exam="+ exam_tbl_exam,true);
    xmlhttp.send(null);
}
    </script>

</html>

<?php
if(isset($_POST["Click"])){
    $q_no=$_POST["q_no"];
    $exam_question=$_POST["exam_question"];
    $exam_ch1=$_POST["exam_ch1"];
    $exam_ch2=$_POST["exam_ch2"];
    $exam_ch3=$_POST["exam_ch3"];
    $exam_ch4=$_POST["exam_ch4"];
    $exam_answer=$_POST["exam_answer"];

    $sql="insert into tbl_exam(q_no,exam_question,exam_ch1,exam_ch2,exam_ch3,exam_ch4,exam_answer)values('$q_no','$exam_question','$exam_ch1','$exam_ch2','$exam_ch3','$exam_ch4','$exam_answer')";
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="exam1.php?e=1"</script>');
                     }
            else
            {
            header("location:exam1.php?e=1");
            die();
            }
        }
    }
    }    
?>

</script>
<?php


mysqli_close($con);			
?> 