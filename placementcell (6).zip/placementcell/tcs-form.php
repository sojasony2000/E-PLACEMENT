
<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?><!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/google f.css">
</head>
<body>
<div class="form">
	<div class="title-div">
	<h1> Placement Drive for BCA,BSc,B.Tech,MCA,MSc</h1>
	<p></p>
	<p class="required">*Required</p>
   </div>
   <form class="form" action="tcs-form.php" method="POST" name="frm" >
   <div class="name-div">
	<div class="name">Name <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="stud_name" placeholder="Your answer"></div>
   </div>
   
   <div class="email-div">
	<div class="name">EmailId <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="mail_id" placeholder="Your Mailid"></div>
   </div>

   <div class="college-div">
	<div class="name">Enter your college name<span class="required">*</span></div>
	<div class="input-div"><input type="input" name="clge_name" placeholder="Your clge name"></div>
   </div>
   
   <div class="mobile-div">
	<div class="name">MobileNo</div>
	<div class="input-div"><input type="input" name="mobile" placeholder="Your mobile no"></div>
   </div>

   <div class="course-div">
	<div class="name">Course</div>
	<div class="input-div"><input type="input" name="course" placeholder="Your course"></div>
   </div>

   <div class="log-div">
	<div class="name">Have any backlogs</div>
	<div class="input-div"><input type="input" name="logs" placeholder=""></div>
   </div>

   <div>
   <input class="btn" type="submit" name="Click" ></a>
   </div>
   
   
   <div class="last-div">
     <br><br><h2>Google Form</h2>
   </div>
	<div>
    <a href="recruit.php">Back</a>
</div>

</div>

</body>
<script>
    function acceptOnlyNumbers(event) {
        var iKeyCode = (event.which) ? event.which : event.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }
  </script>

</html>
<?php
if(isset($_POST["Click"])){
    $id=$_SESSION['log_id'];
    $stud_name=$_POST["stud_name"];
    $mail_id=$_POST["mail_id"];
    $clge_name=$_POST["clge_name"];
    $mobile=$_POST["mobile"];
    $course=$_POST["course"];
    $logs=$_POST["logs"];
    $status=$_POST["status"];

    $sql="insert into tbl_studreg(log_id,stud_name,mail_id,clge_name,mobile,course,logs,status)values('$id','$stud_name','$mail_id','$clge_name','$mobile','$course','$logs','not placed')";
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="alert.php?e=1"</script>');
                     }
            else
            {
            header("location:tcsform.php?e=1");
            die();
            }
        }
  
    }  
}
?>

