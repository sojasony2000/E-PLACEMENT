<?php

include('connect.php');


$query = "
SELECT * FROM tbl_reg 
";

if(isset($_POST['filter_mark_ten'], $_POST['filter_mark_two'], $_POST['filter_mark_ug']) && $_POST['filter_mark_ten'] != '' && $_POST['filter_mark_two'] != '' && $_POST['filter_mark_ug'] != '')
{
 $query .= '
 WHERE 10th mark = "'.$_POST['filter_mark_ten'].'" 12th mark = "'.$_POST['filter_mark_two'].'"  AND ug mark = "'.$_POST['filter_mark_ug'].'"
 ';
}

$query1 = '';

if($_POST["length"] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$statement = $connect->prepare($query . $query1);

$statement->execute();

$result = $statement->fetchAll();


function count_all_data($connect)
{
 $query = "SELECT * FROM tbl_reg";
 $statement = $connect->prepare($query);
 $statement->execute();
 return $statement->rowCount();
}

$output = array(
 "draw"       =>  intval($_POST["draw"]),
 "recordsTotal"   =>  count_all_data($connect),
 "recordsFiltered"  =>  $number_filter_row,
 "data"       =>  $data
);

echo json_encode($output);

?>
