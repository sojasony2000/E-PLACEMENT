<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/style4.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     </head>
     
   </head>
<body>
  <?php
  include "tponav.php";
  ?>
    <br><br><br>
    <main>
    <section id="add-event">
    <h1 class="section-title">Events</h1>
    <form class="form" action="mock.php" method="POST" name="frm" onsubmit="" >
                <input type="text" name="event_names"id="event_names" cols="10" rows="10" placeholder="Event Name" required><br>
                <textarea id="event_descp"name="event_descp" cols="30" rows="10" placeholder="Description..." required></textarea><br>
                <input type="text" name="event_link"id="event_link" cols="10" rows="10" placeholder="Event link" required><br>
                <label for="myform"><input type="submit" class="btn btn-primary"  value="Add" name="Click">
</form>
</main>
<button style="background-color:blue"><a href="events.php">Back</a></button>

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $event_names=$_POST["event_names"];
    $event_descp=$_POST["event_descp"];
    $event_link=$_POST["event_link"];

    $sql="insert into tbl_mock(event_names,event_descp,event_link)values('$event_names','$event_descp','$event_link')";  
  if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="mock.php?e=1"</script>');
                     }
            else
            {
            header("location:mock.php?e=1");
            die();
            }
        }
  
    }   } 
?>