<?php
session_start();
include "connect.php";
if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

?>
<html>
    <link rel="stylesheet" href="css/reg2.css">
<head>
    <title>Registration Form</title>
</head>
<body>
    <div class="container">
        <header>Registration</header>

        <form action="update.php" method="POST">
            <div class="form first">
                <div class="details">
                    <span class="title">Information</span>

                    <div class="fields">
                    <div class="input-field">
                            <label>Age:</label>
                            <input type="age" name="age" id="age"placeholder="Enter age" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>

                      <br> <div class="input-field">
                            <label>Mobile:</label>
                            <input type="tel" name="mobile" placeholder="Enter mobile number" maxlength="10" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>

                        <div class="input-field">
                            <label>City:</label>
                            <input type="text"  name="city" placeholder="Enter city" required>
                        </div>

                        <div class="input-field">
                            <label for="state">State:</label>
                            <input type="text" name="state" placeholder="Enter state" required>

                        </div>

                        <div class="input-field">
                            <label>Pincode:</label>
                            <input type="number" name="pincode" placeholder="Enter pincode" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>
                        <div class="input-field">
                        <label for="gender"> Select you gender:</label><br>
                            <select name="gender">
                                <option value="none" selected>Gender</option>
                                <option value="male">M</option>
                                <option value="female">F</option>
                                <option value="other">other</option>
                            </select>
                        </div>

                        <div class="details">
                    <span class="title">Education Details</span>

                    <div class="fields">
                    <div class="input-field">
                            <label>10th School:</label>
                            <input type="text" name="school_name"id="school_name" placeholder="E nter your school" required>
                        </div>

                        <div class="input-field">
                            <label>10th year:</label>
                            <input type="date" name="tenth" id="tenth" placeholder="Enter the date" required>
                        </div>

                        <div class="input-field">
                            <label>Board:</label>
                            <input type="text" name="tenth_board" id="tenth_board" placeholder="Enter the board" required>
                        </div>
                        
                        <div class="input-field">
                            <label>Percentage:</label>
                            <input type="text" name="mark_ten" id="mark_ten" placeholder="Enter your percentage" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>

                        <div class="input-field">
                            <label>+2 School:</label>
                            <input type="text" name="plus_two" id="plus_two" placeholder="Enter school name" required>
                        </div>

                        <div class="input-field">
                            <label>+2 year:</label>
                            <input type="date" name="plustwo" id="plustwo"placeholder="Enter the year" required>
                        </div>

                        <div class="input-field">
                            <label>Board:</label>
                            <input type="text" name="plustwo_board" id="plustwo_board" placeholder="Enter the board" required>
                        </div>

                        <div class="input-field">
                            <label>Percentage:</label>
                            <input type="text" name="mark_two" id="mark_two" placeholder="Enter your percentage" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>

                        <div class="input-field">
                            <label>Specialization:</label>
                            <input type="text" name="specialization" id="specialization"placeholder="Enter specialization" required>
                        </div>

                        <div class="fields">
                            <div class="input-field">
                            <label>UG College:</label>
                            <input type="text" name="ug_clge" id="ug_clge" placeholder="Enter college name" required>
                        </div>

                        <div class="input-field">
                            <label>UG year:</label>
                            <input type="date" name="ug"id="ug" placeholder="Enter the year" required>
                        </div>

                        <div class="input-field">
                            <label>University:</label>
                            <input type="text" name="ug_university" id="ug_university" placeholder="Enter the university" required>
                        </div>

                        <div class="input-field">
                            <label>Course:</label>
                            <input type="text" name="ug_course" id="ug_course" placeholder="Enter your course" required>
                        </div>

                        <div class="input-field">
                            <label>UG %:</label>
                            <input type="text" name="mark_ug" id="mark_ug" placeholder="Enter your percentage" onkeypress='javascript:return acceptOnlyNumbers(event)'required>
                        </div>
                    </div>
                        <div class="input-field">
                            <label>PG College:</label>
                            <input type="text" name="pg_clge" id="pg_clge" placeholder="Enter college name" required>
                        </div>

                        <div class="input-field">
                            <label>PG year:</label>
                            <input type="date" name="pg" id="pg"placeholder="Enter the year" required>
                        </div>

                        <div class="input-field">
                            <label>University:</label>
                            <input type="text" name="pg_university" id="pg_university" placeholder="Enter the university" required>
                        </div>

                        <div class="input-field">
                            <label>Course:</label>
                            <input type="text" name="pg_course" id="pg_course" placeholder="Enter your course" required>
                        </div>

                        <div class="input-field">
                            <label>PG %:</label>
                            <input type="text" name="mark_pg" id="mark_pg" placeholder="Enter your percentage" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>

                        <div class="input-field">
                            <label>No.of arrears:</label>
                            <input type="text" name="arrear" id="arrear" placeholder="Enter no.of arrears" onkeypress='javascript:return acceptOnlyNumbers(event)' required>
                        </div>   
                    </div>
                </div>

                                       
                    <br>
                    <button class="submit">
                    <input type="submit" value="Add" name="Click">
                    <br><br><br><br><br></span>
                        </button>
                       

                        <button class="submit" ><a href="profile.php">Back</a></button>
                    </div>
                </div>   
            </div>     
        <form>    
        <script>
    function acceptOnlyNumbers(event) {
        var iKeyCode = (event.which) ? event.which : event.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }
  </script>   
    </body>

</html>

<?php
if(isset($_POST["Click"])){
    $age=$_POST["age"];
    $mobile=$_POST["mobile"];
    $city=$_POST["city"];
    $state=$_POST["state"];
    $pincode=$_POST["pincode"];
    $gender=$_POST["gender"];
    $school_name=$_POST["school_name"];
    $tenth=$_POST["tenth"];
    $tenth_board=$_POST["tenth_board"];
    $mark_ten=$_POST["mark_ten"];
    $plus_two=$_POST["plus_two"];
    $plustwo=$_POST["plustwo"];
    $plustwo_board=$_POST["plustwo_board"];
    $mark_two=$_POST["mark_two"];
    $specialization=$_POST["specialization"];
    $ug_clge=$_POST["ug_clge"];
    $ug=$_POST["ug"];
    $ug_university=$_POST["ug_university"];
    $ug_course=$_POST["ug_course"];
    $mark_ug=$_POST["mark_ug"];
    $pg_clge=$_POST["pg_clge"];
    $pg=$_POST["pg"];
    $pg_university=$_POST["pg_university"];
    $pg_course=$_POST["pg_course"];
    $mark_pg=$_POST["mark_pg"];
    $arrear=$_POST["arrear"];
    $id=$_SESSION['log_id'];
    $sql="insert into tbl_reg(age,mobile,city,state,pincode,gender,school_name,tenth,tenth_board,mark_ten,plus_two,plustwo,plustwo_board,mark_two,specialization,ug_clge,ug,ug_university,ug_course,mark_ug,pg_clge,pg,pg_university,pg_course,mark_pg,arrear,log_id)values('$age','$mobile','$city','$state','$pincode','$gender','$school_name','$tenth','$tenth_board','$mark_ten','$plus_two','$plustwo','$plustwo_board','$mark_two','$specialization','$ug_clge','$ug','$ug_university','$ug_course','$mark_ug','$pg_clge','$pg','$pg_university','$pg_course','$mark_pg','$arrear','$id')";
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="update.php?e=1"</script>');
                     }
            else
            {
            header("location:profile.php?e=1");
            die();
            }
        }
    }
    }    
?>

</script>
<?php


mysqli_close($con);			
?> 