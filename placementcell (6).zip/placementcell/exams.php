
<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href='css/examstyle.css' rel='stylesheet'>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">TPO</span>
    </div>
      <ul class="nav-links">
      <li>
          <a href="insert.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Student</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Drives</span>
          </a>
        </li>
        <li>
          <a href="exam1.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add exam</span>
          </a>
        </li>
        <li>
          <a href="list.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Student List</span>
          </a>
        </li>
        <li>
          <a href="events.php">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Events</span>
          </a>
        </li>
       
        <li class="log_out">
          <a href="logout1.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="profile-details">
        <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
                <span class="photo"><?= $r['1']?></span>
        <i class='' ></i>
      </div>
    </nav>
<br><br><br><br>

    <div class="Fields">
<div>
<div class="formContainer">
<form>
<div class="Fields">
<div>
<h3>Add Exam </h3>
<form class="form" action="exams.php" method="POST" name="frm" >
<label for="ename">Exam Name</label>
<input type="text" id="exam_name" name="exam_name" />
<label for="text"> Exam Time</label>
<input type="text" id="exam_time_in_minutes" name="exam_time_in_minutes" />
<button type="submit" class="registerbtn" name="Click">Add</button>
</form>
</div>
</div>
  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $category=$_POST["exam_name"];
    $exam_time=$_POST["exam_time_in_minutes"];

    $sql1="insert into exam_category(exam_name,exam_time_in_minutes)values('$exam_name','$exam_time_in_minutes')";
                if(headers_sent())
                    {
                        ?>
                         <script>
                        alert("Inserted successfully");
                        </script>
                        <?php
                         die('<script type="text/javascript">window.location.href="exams.php?e=1"</script>');
                     }
            else
            {
            header("location:tpo dashboard.php?e=1");
            die();
            }
        }
    }          

?>