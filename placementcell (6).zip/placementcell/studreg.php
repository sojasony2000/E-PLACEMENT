<?php
session_start();
include "connect.php";

$r_id=GET['log_id'];
$query = "select * from tbl_drive where drive_id='$r_id'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$lid=$r["drive_id"]; 
#echo $pid;


mysqli_query($conn,"select from tbl_drive where drive_id=$lid");
header('location:recruit.php');
?>