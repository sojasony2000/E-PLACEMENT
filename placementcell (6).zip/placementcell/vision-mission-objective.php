<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Vision, Mission & Objective</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<body>
<div class="page-wrapper">

<div class="preloader"></div>

<header class="main-header">

<div class="header-upper">
<div class="auto-container">
<div class="clearfix">
<div class="pull-left logo-box">
<div class="logo"><a href="home.php"><img src="images/gupsc-logo.png" alt="" title="Placement cell"></a></div>
</div>
<div class="nav-outer clearfix">

<nav class="main-menu navbar-expand-md">
<div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
<ul class="navigation clearfix">
<li><a href="home.php"> <i class="fa fa-home"></i></a></li>
<li class="dropdown"><a href="#">About Us</a>
<ul>
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
</ul>
</li>
<li class="dropdown"><a href="#">Placement</a>
<ul>
<li><a href="log1.php">Login</a></li>
</ul>
</li>

</nav>
</div>
</div>
</div>
</div>


<div class="sticky-header">
<div class="auto-container clearfix">

<div class="logo pull-left">
<a href="index.php" class="img-responsive"><img src="images/gupsc-logo.png" alt="" title=""></a>
</div>





</header> 

<section class="page-title" style="background-image:url(images/background/pattern-21.png)">
<div class="auto-container">

<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-6.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-7.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-8.png)"></div>

<div class="icon-four" style="background-image:url(images/icons/icon-9.png)"></div>

<div class="icon-five" style="background-image:url(images/icons/icon-10.png)"></div>

<div class="icon-six" style="background-image:url(images/icons/icon-6.png)"></div>
</div>
<div class="inner-container clearfix">
<div class="pull-left">
<h1>About Placement Cell</h1>
</div>
<div class="pull-right">
<ul class="bread-crumb clearfix">
<li><a href="home.php">Home</a></li>
<li>About Placement Cell</li>
</ul> </div>
</nav>
</div>
</div>
</div>



</header> 

<section class="page-title" style="background-image:url(images/background/pattern-21.png)">
<div class="auto-container">

<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-6.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-7.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-8.png)"></div>

<div class="icon-four" style="background-image:url(images/icons/icon-9.png)"></div>

<div class="icon-five" style="background-image:url(images/icons/icon-10.png)"></div>

<div class="icon-six" style="background-image:url(images/icons/icon-6.png)"></div>
</div>
<div class="inner-container clearfix">
<div class="pull-left">
<h1>Vision, Mission & Objective</h1>
</div>
<div class="pull-right">
<ul class="bread-crumb clearfix">
<li><a href="home.php">Home</a></li>
<li>Vision, Mission & Objective</li>
</ul>
</div>
</div>
</div>
</section>

<section class="services-section-two style-two">
<div class="auto-container">

<div class="sec-title centered">
<div class="title">Our Vision</div>
<div class="separator"><span></span></div>
<h2>To improve the employability of the students and develop a "Society of Winners".</h2>
<hr />
</div>
</div>
</section>


<section class="services-section">
<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-1.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-2.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-3.png)"></div>

<div class="icon-four" style="background-image:url(images/icons/icon-4.png)"></div>
</div>
<div class="auto-container">

<div class="sec-title centered">
<div class="title">We Help You</div>
<div class="separator"><span></span></div>
<h2>Our Mission</h2>
</div>
<div class="row clearfix">

<div class="services-block col-lg-4 col-md-6 col-sm-12">
<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
<div class="icon-box">
<span class="icon"><img src="images/icons/service-2.png" alt="" /></span>
</div>
<h3>To prepare the students for different jobs. </a></h3>
<a class="plus-icon fa fa-plus" href="#"></a>
</div>
</div>

<div class="services-block col-lg-4 col-md-6 col-sm-12">
<div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
<div class="icon-box">
<span class="icon"><img src="images/icons/service-1.png" alt="" /></span>
</div>
<h3>Help students to choose their field of career.</a></h3>
<a class="plus-icon fa fa-plus" href="#"></a>
</div>
</div>

<div class="services-block col-lg-4 col-md-6 col-sm-12">
<div class="inner-box wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
<div class="icon-box">
<span class="icon"><img src="images/icons/service-3.png" alt="" /></span>
</div>
<h3>To motivate the students to improve their skill.</a></h3>
<a class="plus-icon fa fa-plus" href="#"></a>
</div>
</div>
</div>
</div>
</section>

<section class="about-section">
<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-1.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-2.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-4.png)"></div>
</div>
<div class="auto-container">
<div class="row clearfix">

<div class="title-column col-lg-6 col-md-12 col-sm-12">
<div class="inner-column">

<div class="sec-title">
<div class="title">Our Objective</div>
<div class="separator"><span></span></div>
<h2>Objectives of the Placement Cell</h2>
</div>
<div class="text">
<ul class="list-style-two">
<li>To know the requirements of the industry and other sectors of the economy.</li>
<li>To prepare the students as per the need of the industry and other sectors of the economy.</li>
<li>To develop an eco-system with industry and other sectors of the economy.</li>
<li>To provide required assistance to improve the skills among the students.</li>
<li>To Coordinate with corporate sector for providing them better Human Resource.</li>
</ul>
</div>
<p>&nbsp;</p><p>&nbsp;</p>
</div>
</div>

<div class="image-column col-lg-6 col-md-12 col-sm-12">
<div class="inner-column">
<div class="image">
<img src="images/resource/about-1.png" alt="" />
</div>
</div>
</div>
</div>
</div>
</section>


<footer class="main-footer margin-top" style="background-image:url(images/background/4.jpg);margin-top:60px;">
<div class="auto-container">

<div class="widgets-section">
<div class="row clearfix">

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">

<div class="footer-column col-lg-7 col-md-6 col-sm-12">
<div class="footer-widget logo-widget">
<div class="logo">
<a href="index.php"><img src="images/gupsc-logo.png" alt="" /></a>
</div>
<div class="text">
<p>Placement Cell of the University aims to develop the students in such a way that their academic knowledge and other skills help to build their career in a pre-decided manner.
</p>
</div>

</div>
</div>

<div class="footer-column col-lg-5 col-md-6 col-sm-12">
<div class="footer-widget links-widget">
<h4>About Us</h4>
<ul class="list-link">
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
</ul>
</div>
</div>
</div>
</div>

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">
</div>
</div>
</div>
</div>
</div>

<div class="footer-bottom">
<div class="auto-container">
<div class="inner-container">
<div class="row clearfix">

<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
<div class="copyright">2020-2022 &copy; Powered by <a href="https://cyberdairy.com">Kingston college</a></div>
</div>

<div class="social-column col-lg-6 col-md-6 col-sm-12">

<a href="disclaimer.php" style="color:#ffffff;"><strong>Disclaimer</strong></a>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>


<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-up"></span></div>
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>
</body>
</html>
