<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

}

if(isset($_POST['viewdetails'])){
  $reg_id=$_POST['reg_id'];
  $_SESSION['reg_id']=$reg_id;
  header('location:details.php');
}

?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="css/style3.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
   </head>
<body>
 <?php
 include "tponav.php";
 ?>

    <br><br><br><br><br><br><br><break><div class="content-table">
    
           
    <html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
</head>

<body>
    <div class="table">
        <div class="table_header">
            <p>Student Details</p>
            <div class="input-group rounded">
           
            <input id="myInput" type="text" placeholder="Search..">
            <span class="input-group-text border-0" id="search-addon">
              <i class="fas fa-search"></i>
              <div id="datatable"></div>
            </span>
          </div>
            
        </div>
      
</form>
        <div class="table_section">
            <table>
                <thead>
                    <tr>
                    <th>S.No</th>    
                    <th>EnrollNo</th>
                    <th>Full name</th>
                    <th>Father name</th>
                    <th>Address</th>
                    <th>DOB</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    
                    
                    
                    </tr>
                </thead>
                
                <tbody id="myTable">
                <?php
 $count=1;
 
 $sel_query="SELECT * FROM `tbl_reg`,tbl_regn where tbl_reg.log_id=tbl_regn.log_id and tbl_reg.mark_ten>60 and tbl_reg.mark_two>60 and tbl_reg.mark_ug>60 and tbl_reg.mark_pg>60"; 
 $result = mysqli_query($con,$sel_query);
 while($row = mysqli_fetch_assoc($result))
  { ?>
 <tr><td><center><?php echo $count; ?></center></td>
 <td><center><?php echo $row["no"]; ?></center></td>
 <td><center><?php echo $row["s_name"]; ?> </center></td>
 <td><center><?php echo $row["father_name"]; ?> </center></td>
 <td><center><?php echo $row["address"]; ?></center></td>
 <td><center><?php echo $row["birth_date"]; ?></center></td>
 <td><center><?php echo $row["email"]; ?></center></td>
 <td><center><?php echo $row["mobile"]; ?></center></td>
 
  
 <td width=300><form method="POST" action="verifyemail.php">
<button><a href ="details.php?id=<?php echo $row["log_id"];?>">Download</a></button>
 <!--<button type="submit" name="viewdetails">Download</button>-->
 <?php $count++;  }?>
 </tbody>
               
            </table>

           <br><a href="verifyemail.php"> <button style="background-color: powderblue;"type="email" value="email" name="email">Send Email</button></a>
            
    </div>
   
 
</body>

</html>
  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
</script>


 


</body>

</html>


<?php 
{
 
 

}
           

?>