<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/google f.css">
</head>
<body>
<div class="form">
	<div class="title-div">
	<h1>TCS Training Program</h1>
	<p></p>
	<p class="required">*Required</p>
   </div>
   
   <form class="form" action="tcsform.php" method="POST" name="frm" >

   <div class="name-div">
	<div class="name">Name <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="s_name" placeholder="Your answer" maxlength="18" onkeypress='style=' text-transform: uppercase;'' required></div>
   </div>
   
   <div class="email-div">
	<div class="name">EmailId <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="email_id" placeholder="Your Mailid" required></div>
   </div>

   <div class="college-div">
	<div class="name">Enter your college name<span class="required">*</span></div>
	<div class="input-div"><input type="input" name="clg_name" placeholder="Your clge name" required></div>
   </div>
   
   <div class="mobile-div">
	<div class="name">MobileNo</div>
	<div class="input-div"><input type="input" name="mobile_no" placeholder="Your mobile no" maxlength="10" onkeypress='javascript:return acceptOnlyNumbers(event)' required></div>
   </div>

   <div class="course-div">
	<div class="name">Course</div>
	<div class="input-div"><input type="input" name="course_name" placeholder="Your course" required></div>
   </div>
   <div>
   <input type="submit" class="btn"  value="Submit" name="Click">
   </div>
   <br><br><br>
   <div>
    <a href="alert.php">Back</a>
</div>
 
   <div class="last-div">
     <br><br><h2>Google Form</h2>
   </div>
	

</div>
<script>
    function acceptOnlyNumbers(event) {
        var iKeyCode = (event.which) ? event.which : event.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }
  </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $id=$_SESSION['log_id'];
    $s_name=$_POST["s_name"];
    $email_id=$_POST["email_id"];
    $clg_name=$_POST["clg_name"];
    $mobile_no=$_POST["mobile_no"];
    $course_name=$_POST["course_name"];
    $pay_status=$_POST["pay_status"];

    $sql="insert into tbl_cmpnyreg(log_id,s_name,email_id,clg_name,mobile_no,course_name,pay_status)values('$id','$s_name','$email_id','$clg_name','$mobile_no','$course_name','pending')";
    if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="alert.php?e=1"</script>');
                     }
            else
            {
            header("location:tcsform.php?e=1");
            die();
            }
        }
  
    }  
}
?>
