<!DOCTYPE html>
<!--code by webdevtrick (webdevtrick.com) -->
<html>

<head>
	<meta charset=UTF-8" />
	
	<title>PHP Quiz</title>
	
	<link rel="stylesheet" type="text/css" href="style6.css" />
</head>

<body>

	<div id="page-wrap">

		<h1>Result | Webdevtrick.com</h1>
		
        <?php
            
            $answer1 = $_POST['exam_ch1'];
            $answer2 = $_POST['exam_ch2'];
            $answer3 = $_POST['exam_ch3'];
            $answer4 = $_POST['exam_ch4'];
            
        
            $totalCorrect = 0;
            
            if ($answer1 == "C") { $totalCorrect++; }
            if ($answer2 == "D") { $totalCorrect++; }
            if ($answer3 == "A") { $totalCorrect++; }
            if ($answer4 == "B") { $totalCorrect++; }
            if ($answer5 == "D") { $totalCorrect++; }
            
            echo "<div id='results'>$totalCorrect / 5 correct</div>";
            
        ?>
	
	</div>

</body>

</html>