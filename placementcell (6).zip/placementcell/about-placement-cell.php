<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>About Placement Cell</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<body>
<div class="page-wrapper">

<div class="preloader"></div>

<header class="main-header">

<div class="header-upper">
<div class="auto-container">
<div class="clearfix">
<div class="pull-left logo-box">
<div class="logo"><a href="home.php"><img src="images/gupsc-logo.png" alt="" title="Placement cell"></a></div>
</div>
<div class="nav-outer clearfix">

<nav class="main-menu navbar-expand-md">
<div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
<ul class="navigation clearfix">
<li><a href="index.php"> <i class="fa fa-home"></i></a></li>
<li class="dropdown"><a href="#">About Us</a>
<ul>
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
</ul>
</li>
<li class="dropdown"><a href="#">Placement</a>
<ul>
<li><a href="log1.php">Login</a></li>
</ul>
</li>

</nav>
</div>
</div>
</div>
</div>


<div class="sticky-header">
<div class="auto-container clearfix">

<div class="logo pull-left">
<a href="index.php" class="img-responsive"><img src="images/gupsc-logo.png" alt="" title=""></a>
</div>





</header> 

<section class="page-title" style="background-image:url(images/background/pattern-21.png)">
<div class="auto-container">

<div class="section-icons">

<div class="icon-one" style="background-image:url(images/icons/icon-6.png)"></div>

<div class="icon-two" style="background-image:url(images/icons/icon-7.png)"></div>

<div class="icon-three" style="background-image:url(images/icons/icon-8.png)"></div>

<div class="icon-four" style="background-image:url(images/icons/icon-9.png)"></div>

<div class="icon-five" style="background-image:url(images/icons/icon-10.png)"></div>

<div class="icon-six" style="background-image:url(images/icons/icon-6.png)"></div>
</div>
<div class="inner-container clearfix">
<div class="pull-left">
<h1>About Placement Cell</h1>
</div>
<div class="pull-right">
<ul class="bread-crumb clearfix">
<li><a href="index.php">Home</a></li>
<li>About Placement Cell</li>
</ul>
</div>
</div>
</div>
</section>


<div class="sidebar-page-container">
<div class="auto-container">
<div class="row clearfix">

<div class="content-side col-lg-8 col-md-12 col-sm-12">
<div class="blog-single">
<div class="inner-box">
<div class="image">
<img src="images/about-university.jpg" alt="" />
</div>
<div class="lower-content">
<div class="text" style="text-align:justify">
<p>Placement Cell of the University aims to develop the students in such a way that their academic knowledge and other skills help to built their career in a pre-decided manner. Though the University is mainly providing traditional degrees but the Cell through its activities and events keep motivating the students of different stream on regular basis for deciding their career goals at early stage of higher education and provide assistance to achieve their career goals. </p>
<blockquote>
<div class="quote-icon flaticon-left-quote"></div>
<div class="quote-text">To ensure maximum placements, the Cell initiated the registration of all the students of the University through the website of the Cell in which all the information of the students including their career goals are being collected. The Cell is also collecting the CV’s of the last semester students of all the courses so that the Cell can have all the relevant data for contacting the Companies for campus placement drive. </div>
</blockquote>
<p> Companies of repute keep contacting us for providing the details of the students of different streams. In the previous year, the Cell conducted campus drive in the Department of Computer Science, Department of Business Management, Department of Commerce and Department of Pharmacy. The Azim Premji Foundation has also conducted the test in the University for recruiting the students of different streams. The selection process is at final stage. Prism Cement Ltd have also shortlisted our LL.B. ( 5 year Course) for Law Officer position in the company. Nestle India have also invited the list of eligible candidates for the position of Nutrition Trainees. The Cell is planning to start campus drive in the month of March. </p>
<p>The Cell is planning to start different activities for preparing the student for competitive examination. The Monthly Commerce Quiz is one of the activities by which the student of Commerce and other who are preparing for MPPSC, UPSC and other state and national level competitions can strengthen their GK of commerce and economic affairs. 8 monthly commerce quizzes have been conducted till date and the next quiz will be conducted in the month of March. </p>
<blockquote>
<div class="quote-icon flaticon-left-quote"></div>
<div class="quote-text">The quiz is gaining attraction amongst students and total 348 students from the University and other parts of the country have been registered for this Commerce Quiz. The Cell is planning to start quizzes covering other subjects also.</div>
</blockquote>
<p> The University has a Startup Cell and the activities of the Cell are encouraging the students to start their own businesses. Total 5 active businesses have been started under the Cell and others are under pipeline. The activities of the Cell have also been incorporated with this website to provide consolidated information of the activities of both the Cell i.e. Placement Cell and Startup Cell. </p>
<p>For Better results it is essential that the students of all the streams registered in the Cell and get benefited of all the activities of the Cell. The active participation of the students will help the Cell to add new activities so that the employability of the student can be increased.
</p>
</div>
</div>
</div>
</div>
</div>

<div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
<aside class="sidebar">

<div class="sidebar-widget popular-posts">
<div class="sidebar-title"><h2>Latest Announcement</h2></div>
<article class="post">
<div class="text"><a href="#">Business Idea Submission Platform (24*7) Nirantar</a></div>
<div class="post-info">17-03-2022</div>
</article>
<article class="post">
<div class="text"><a href="#">Selected students list of Azim Premji Foundation Campus Associate Program 2022</a></div>
<div class="post-info">14-03-2022</div>
</article>
<article class="post">
<div class="text"><a href="#">Motivational Lectures and Award Ceremony of Business Idea Competition</a></div>
<div class="post-info">14-03-2022</div>
</article>
</div>


</aside>
</div>
</div>
</div>
</div>


<footer class="main-footer margin-top" style="background-image:url(images/background/4.jpg);margin-top:60px;">
<div class="auto-container">

<div class="widgets-section">
<div class="row clearfix">

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">

<div class="footer-column col-lg-7 col-md-6 col-sm-12">
<div class="footer-widget logo-widget">
<div class="logo">
<a href="index.php"><img src="images/gupsc-logo.png" alt="" /></a>
</div>
<div class="text">
<p>Placement Cell of the University aims to develop the students in such a way that their academic knowledge and other skills help to build their career in a pre-decided manner.
</p>
</div>

</div>
</div>

<div class="footer-column col-lg-5 col-md-6 col-sm-12">
<div class="footer-widget links-widget">
<h4>About Us</h4>
<ul class="list-link">
<li><a href="about-university.php">About University</a></li>
<li><a href="about-placement-cell.php">About Placement Cell</a></li>
<li><a href="vision-mission-objective.php">Vision, Mission & Objective</a></li>
</ul>
</div>
</div>
</div>
</div>

<div class="big-column col-lg-6 col-md-12 col-sm-12">
<div class="row clearfix">

<div class="footer-column col-lg-6 col-md-6 col-sm-12">
<div class="footer-widget links-widget">
</ul>
</div>
</div>


</div>
</div>
</div>
</div>
</div>

<div class="footer-bottom">
<div class="auto-container">
<div class="inner-container">
<div class="row clearfix">

<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
<div class="copyright">2020-2022 &copy; Powered by <a href="https://cyberdairy.com">Kingston college</a></div>
</div>

<div class="social-column col-lg-6 col-md-6 col-sm-12">

<a href="disclaimer.php" style="color:#ffffff;"><strong>Disclaimer</strong></a>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>


<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-up"></span></div>
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>
</body>
</html>
