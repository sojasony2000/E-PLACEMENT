<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/style4.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script type="text/javaScript">
        function reg()
        {

          var date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(0[1-9]|1[1-9]|2[1-9])$/;
          var testDate = "03/17/21";

          if(document.getElementById("event_name").value =='')
          {
            event_name.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Please enter event event_name';
              return false;
          }
          else if(!letters.test(document.getElementById("event_name").value))
          {  event_name.style.border="3px solid red";
            document.getElementById("demo").innerHTML = 'Name field required any characters';
              return false;
          }
          // regular expression to match required date format
          
          else{
            function validateDate_MMDDYYYY(input_date) {
            var parts = input_date.split(/[\/\-\.]/);

            if (parts.length < 3) {
                return false;
            }
            var dt = new Date(parts[2], parts[0] - 1, parts[1]);
            console.log("date is ", dt.toString());
            return (dt && dt.getMonth() === parseInt(parts[0], 10) - 1)
          }
          }
      
          else{
            function validateForm(event) {
              var date_str = document.getElementById('event_date').value;
              if (!validateDate_MMDDYYYY(date_str)) {
                  document.getElementById('date_error').classList.remove('hidden');
              } else {
                  document.getElementById('date_error').classList.add('hidden');
                  alert("validation success")
              }
              event.preventDefault();
          }
        }
        

          
        
          // regular expression to match required time format
          re = /^\d{1,2}:\d{2}([ap]m)?$/;

          if(form.starttime.value != '' && !form.starttime.value.match(re)) {
            alert("Invalid time format: " + form.starttime.value);
            form.starttime.focus();
            return false;
          }

          alert("All input fields have been validated!");
          return true;
        }
        document.getElementById('myform').addEventListener('Click', validateForm);

      </script>
   </head>
<body>
  <?php
  include "tponav.php";
  ?>

    
    <main>
        
        <section id="add-event">
            <h1 class="section-title">New Event</h1>
            <form class="form" action="events.php" method="POST" name="frm" onsubmit="" >
                <input type="text" name="event_name"id="event_name" cols="10" rows="10" placeholder="Event Name" required><br>
                <label for="myform_date"><input type="date" name="event_date" id="event_date" placeholder="Date" value=""
       min="1995-01-01" max="2022-12-31" required><br> <div class="error hidden" id="date_error" >
                <textarea id="event_desc"name="event_desc" cols="30" rows="10" placeholder="Description..." required></textarea><br>
                <input type="time" name="event_time" id="event_time" placeholder="Time" required><br>
                <label for="myform"><input type="submit" class="btn btn-primary"  value="Add" name="Click">
            </form>
        </section>
    </main>

    <button style="background-color:blue"><a href="mock.php">Next Page</a></button>

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php
if(isset($_POST["Click"])){
    $event_name=$_POST["event_name"];
    $event_date=$_POST["event_date"];
    $event_desc=$_POST["event_desc"];
    $event_time=$_POST["event_time"];

    $sql="insert into event_tbl(event_name,event_date,event_desc,event_time)values('$event_name','$event_date','$event_desc','$event_time')";  
  if(mysqli_query($con,$sql))
  { 
    if(headers_sent())
                    {
                    ?>
                 
                    <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="events.php?e=1"</script>');
                     }
            else
            {
            header("location:events.php?e=1");
            die();
            }
        }
  
    }   } 
?>