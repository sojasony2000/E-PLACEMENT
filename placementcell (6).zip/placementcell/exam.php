<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <link href="./main.css" rel="stylesheet">
    <link href="css/sweetalert.css" rel="stylesheet">
    <link href="css/facebox.css" rel="stylesheet">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">TPO</span>
    </div>
      <ul class="nav-links">
      <li>
          <a href="insert.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Student</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add Drives</span>
          </a>
        </li>
        <li>
          <a href="exam.php" class="active">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Add exam</span>
          </a>
        </li>
        <li>
          <a href="list.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Student List</span>
          </a>
        </li>
        <li>
          <a href="events.php">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Events</span>
          </a>
        </li>
       
        <li class="log_out">
          <a href="logout1.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="profile-details">
        <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
                <span class="photo"><?= $r['1']?></span>
        <i class='' ></i>
      </div>
    </nav>

<br><br><br><br><br><br><br>
<section><div class="modal fade" id="modalForAddQuestion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form class="refreshFrm" id="addQuestionFrm" method="post">
     <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Question<br></h5>
      </div>
      <form class="refreshFrm" method="post" id="addQuestionFrm" action="exam.php">
      <div class="modal-body">
        <div class="col-md-12">
          <div class="form-group">
            <label>Question</label>
            <input type="hidden" name="examId" value="<?php echo $q_id; ?>">
            <input type="" name="exam_question" id="course_name" class="form-control" placeholder="Input question" autocomplete="off">
          </div>

          <fieldset>
            <legend></legend>
            <div class="form-group">
                <label>Choice A</label>
                <input type="" name="exam_ch1" id="exam_ch1" class="form-control" placeholder="Input choice A" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Choice B</label>
                <input type="" name="exam_ch2" id="exam_ch2" class="form-control" placeholder="Input choice B" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Choice C</label>
                <input type="" name="exam_ch3" id="choice_C" class="form-control" placeholder="Input choice C" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Choice D</label>
                <input type="" name="exam_ch4" id="exam_ch4" class="form-control" placeholder="Input choice D" autocomplete="off">
            </div>

            <div class="form-group">
                <label>Correct Answer</label>
                <input type="" name="exam_answer" id="exam_answer" class="form-control" placeholder="Input correct answer" autocomplete="off">
            </div>
          </fieldset>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Now</button>
      </div>
      </form>
</section>

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>
 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/myjs.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript" src="js/sweetalert.js"></script>
<script type="text/javascript" src="js/facebox.js"></script>

</body>
</html>
<?php 
if(isset($_POST['submit'])){
    $exam_question=$_POST["exam_question"];
    $exam_ch1=$_POST["exam_ch1"];
    $exam_ch2=$_POST["exam_ch2"];
    $exam_ch3=$_POST["exam_ch3"];
    $exam_ch4=$_POST["exam_ch4"];
    $exam_answer=$_POST["exam_answer"];

    $sql="insert into tbl_exam(exam_question,exam_ch1,exam_ch2,exam_ch3,exam_ch4,exam_answer)values('$exam_question','$exam_ch1','$exam_ch2','$exam_ch3','$exam_ch4','$exam_answer')";
    if(mysqli_query($con,$sql)){
           if(headers_sent())
                    {
                     ?>
                     <script>
                     alert("Inserted Successfully");
                     </script>
                     <?php
                         die('<script type="text/javascript">window.location.href="exam.php?e=1"</script>');
                     }
            else
            {
            header("location:exam.php?e=1");
            die();
            }
        }
    }
}
            

else{
    ?>
    
    <script>
    alert("error");
    </script>
    <?php
    }
    mysqli_close($con);
    ?>
