<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>TPO Dashboard | Kingston college </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
 <?php
 include "tponav.php";
 ?>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic"> Registered Students  </div>
            <div class="number">4876</div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <span class="iconify" data-icon="uil:user-circle" style="color: #865;" data-width="70"></span>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Placed Students</div>
            <div class="number">2876</div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text"></span>
            </div>
          </div>
          <span class="iconify" data-icon="uil:user-circle" style="color: #865;" data-width="70"></span>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Placements</div>
            <div class="number">76</div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <span class="iconify" data-icon="uil:user-circle" style="color: #865;" data-width="70"></span>
        </div>
        
    </div>

  <script>
      
   let sidebar = document.querySelector(".sidebar");
   let sidebarBtn = document.querySelector(".sidebarBtn");
   sidebarBtn.onclick = function() {
   sidebar.classList.toggle("active");
   if(sidebar.classList.contains("active")){
   sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
 }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>
<?php 
}
            else
            {
                if(headers_sent())
                    {
                         die('<script type="text/javascript">window.location.href="log1.php?e=1"</script>');
                     }
            else
            {
            header("location:log1.php?e=1");
            die();
            }
        }
            

?>