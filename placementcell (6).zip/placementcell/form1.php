<?php
session_start();
include "connect.php";

if(isset($_SESSION['log_id']))
{
 
$id=$_SESSION['log_id'];
$query="SELECT * FROM log_tbl where log_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/google f.css">
</head>
<body>
<div class="form">
	<div class="title-div">
	<h1>6D Technologies Placement Drive for BCA,BSc,B.Tech,MCA,MSc (CSE/ECE/IT)</h1>
	<p></p>
	<p class="required">*Required</p>
   </div>
   
   <div class="name-div">
	<div class="name">Name <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="answer" placeholder="Your answer"></div>
   </div>
   
   <div class="email-div">
	<div class="name">EmailId <span class="required">*</span></div>
	<div class="input-div"><input type="input" name="email" placeholder="Your Mailid"></div>
   </div>

   <div class="college-div">
	<div class="name">Enter your college name<span class="required">*</span></div>
	<div class="input-div"><input type="input" name="college" placeholder="Your clge name"></div>
   </div>
   
   <div class="mobile-div">
	<div class="name">MobileNo</div>
	<div class="input-div"><input type="input" name="answer" placeholder="Your mobile no"></div>
   </div>

   <div class="course-div">
	<div class="name">Course</div>
	<div class="input-div"><input type="input" name="course" placeholder="Your course"></div>
   </div>

   <div class="log-div">
	<div class="name">Have any backlogs</div>
	<div class="input-div"><input type="input" name="answer" placeholder=""></div>
   </div>

   <div>
   <input class="btn" type="submit" name="Submit" ></a>
   </div>
 
   <div class="last-div">
     <br><br><h2>Google Form</h2>
   </div>
	

</div>

</body>
</html>
<?php
}
?>
