<?php
session_start();
include 'connect.php';
if(isset($_SESSION['log_id']))
    $log_id=$_SESSION['log_id'];

$result=mysqli_query($con,"SELECT enrollment,s_name,father_name,address,birth_date,email,age,mobile,city,state,pincode,gender,school_name,tenth,tenth_board,mak_ten,plus_two,plustwo,plustwo_board,mark_two,specialization,ug_clge,ug,ug_university,ug_course,mark_ug,pg_clge,pg,pg_university,pg_course,mark_pg,arrears FROM `tbl_regn`,`tbl_reg` where log_id=$log_id") or die(mysqli_error($con));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Student Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Enrollment No : '. $row['enrollment'],1);
$pdf->Multicell(80,12,'Name : '. $row['s_name'],1);
$pdf->Multicell(80,12,'Address : '. $row['address'],1);
$pdf->Multicell(80,12,'DOB : '. $row['birth_date'],1);
$pdf->Multicell(80,12,'Email : '. $row['email'],1);
$pdf->Multicell(80,12,'Age : '. $row['age'],1);
$pdf->Multicell(80,12,'Mobile : '. $row['mobile'],1);
$pdf->Multicell(80,12,'City : '. $row['city'],1);
$pdf->Multicell(80,12,'State : '. $row['state'],1);
$pdf->Multicell(80,12,'Pincode : '. $row['pincode'],1);
$pdf->Multicell(80,12,'Gender : '. $row['gender'],1);
$pdf->Multicell(80,12,'School_name : '. $row['school_name'],1);
$pdf->Multicell(80,12,'Tenth_year : '. $row['tenth'],1);
$pdf->Multicell(80,12,'Tenth_board : '. $row['tenth_board'],1);
$pdf->Multicell(80,12,'Mark : '. $row['mark_ten'],1);
$pdf->Multicell(80,12,'School : '. $row['plus_two'],1);
$pdf->Multicell(80,12,'Year : '. $row['plustwo'],1);
$pdf->Multicell(80,12,'Board : '. $row['plustwo_board'],1);
$pdf->Multicell(80,12,'Mark: '. $row['mark_two'],1);
$pdf->Multicell(80,12,'Specialization : '. $row['specialization'],1);
$pdf->Multicell(80,12,'College : '. $row['ug_clge'],1);
$pdf->Multicell(80,12,'Year : '. $row['ug'],1);
$pdf->Multicell(80,12,' University : '. $row['ug_university'],1);
$pdf->Multicell(80,12,'Course : '. $row['ug_course'],1);
$pdf->Multicell(80,12,'Percentage : '. $row['mark_ug'],1);
$pdf->Multicell(80,12,'College : '. $row['pg_clge'],1);
$pdf->Multicell(80,12,'Year: '. $row['pg'],1);
$pdf->Multicell(80,12,'University : '. $row['pg_university'],1);
$pdf->Multicell(80,12,'PG_course : '. $row['pg_course'],1);
$pdf->Multicell(80,12,'Percentage : '. $row['mark_pg'],1);
$pdf->Multicell(80,12,'Arrears : '. $row['arrear'],1);


$pdf->Output();
?>