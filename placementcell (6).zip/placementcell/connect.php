<?php

$con=mysqli_connect('localhost','root','','kingston') or die("error");

?>